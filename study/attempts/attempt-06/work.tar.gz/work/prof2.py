import sys
sys.path.insert(0,'work')
import gb, collections
import numpy as np, odometer as od
from odometer import _data,_engine
m=gb.load(sys.argv[1])
_engine._M.reset(int(sys.argv[2]) if len(sys.argv)>2 else 500_000_000,1); data=_data.TrainData()
C=collections.Counter(); L=collections.Counter()
orig=_engine._tick
def tick(n=0):
    f=sys._getframe(1); k='other'; prim=f.f_code.co_name
    while f:
        c=f.f_code
        if c.co_filename.endswith('train.py'):
            k=f'{c.co_name}:{f.f_lineno}'; break
        f=f.f_back
    if k.startswith('fit_tables') : k=k+' '+prim
    C[k]+=int(max(n,0))+2000; L[k]+=1
    orig(n)
_engine._tick=tick
D=sys.modules['odometer._data']; D._engine._tick=tick
try:
    m.fit_tables(data,100000)
except Exception as e: print(e)
tot=sum(C.values()); print('total',tot,'calls',sum(L.values()))
for k,v in C.most_common(28): print(f'{v/tot:.3f} {v:>11} {L[k]:>6} {k}')

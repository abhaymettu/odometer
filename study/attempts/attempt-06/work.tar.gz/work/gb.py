"""Offline harness: cache table params for an entry+seed, then refit only the gate and score on dev."""
import sys, os, json, time, importlib.util, pathlib
for v in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS"): os.environ[v]="1"
ROOT=pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
import numpy as np, odometer as od
from odometer import _data,_engine
def load(path):
    spec=importlib.util.spec_from_file_location("entry",path); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
def score(m,params,n=1024):
    w=_data.heldout_windows("dev",512,1024)[:]
    idx=np.linspace(0,1023,n).astype(int); w=w[idx]
    _engine._M.reset(None,0,mode="eval")
    tot=0.
    arr={k:v._d for k,v in params.items()}
    for s in range(0,len(w),16):
        r=w[s:s+16]
        z=m.forward({k:od.Tensor(a) for k,a in arr.items()},od.Tensor(r[:,:512].astype(np.int32)))._d.astype(np.float64)
        lp=z-z.max(-1,keepdims=True); lp-=np.log(np.exp(lp).sum(-1,keepdims=True))
        tot+=-(np.take_along_axis(lp,r[:,1:,None].astype(int),-1)).sum()
    return tot/(len(w)*512)/np.log(2), _engine._M.used/(len(w)*512)
if __name__=="__main__":
    cmd,table_entry,seed=sys.argv[1],sys.argv[2],int(sys.argv[3])
    name=pathlib.Path(table_entry).parent.name
    cache=ROOT/f"work/cache-{name}-{seed}.npz"
    if cmd=="tables":
        m=load(table_entry); _engine._M.reset(40_000_000_000,seed)
        data=_data.TrainData()
        p=m.fit_tables(data,od.remaining()*m.GATE_SHARE)
        np.savez(cache,**{k:v._d for k,v in p.items()},_used=np.array(_engine._M.used))
        print("cached",cache,_engine._M.used)
    else:
        # gate <table_entry> <seed> <gate_entry> [share] ; gate_entry supplies fit_gate/forward
        g=load(sys.argv[4]); share=float(sys.argv[5]) if len(sys.argv)>5 else 0.08
        st=np.load(cache); p={k:od.Tensor(st[k]) for k in st.files if k!="_used"}
        _engine._M.reset(int(40_000_000_000*share),seed)
        data=_data.TrainData()
        t0=time.time(); q=g.fit_gate(p,data); t1=time.time()
        b,tp=score(g,p|q)
        print(json.dumps(dict(gate=sys.argv[4],share=share,seed=seed,bpb=round(b,5),eval_ticks=round(tp),fit_s=round(t1-t0,1),eval_s=round(time.time()-t1,1))),flush=True)

import sys,os,collections,traceback
sys.path.insert(0,'work'); 
import gb
import numpy as np, odometer as od
from odometer import _data,_engine
m=gb.load(sys.argv[1])
st=np.load('work/cache-v5-11.npz'); p={k:od.Tensor(st[k]) for k in st.files if k!="_used"}
_engine._M.reset(10**12,1); data=_data.TrainData()
C=collections.Counter(); L=collections.Counter()
orig=_engine._tick
def tick(n=0):
    f=sys._getframe(1)
    names=[]
    while f:
        c=f.f_code
        if c.co_filename.endswith('train.py'):
            names.append(f'{c.co_name}:{f.f_lineno}'); break
        f=f.f_back
    k=names[0] if names else 'other'
    C[k]+=int(max(n,0))+2000; L[k]+=1
    orig(n)
_engine._tick=tick
import odometer._data as D; D._engine._tick=tick
q=m.gate_params(); wc=m.window_constants(m.GATE_T)
z,y=data.batch(m.GATE_BATCH,m.GATE_T+m.PAD); x=z[:,m.PAD:]
with od.no_grad():
    p0=m.base_probs(p,z,wc[4]); stats=m.local_stats(z,x,wc)
print('nograd total',sum(C.values()))
od.cross_entropy(m.blend(q,p0,stats,x),m.fold(y[:,m.PAD:])).backward()
tot=sum(C.values()); print('total',tot, 'calls',sum(L.values()))
for k,v in C.most_common(30): print(f'{v/tot:.3f} {v:>10} {L[k]:>5} {k}')

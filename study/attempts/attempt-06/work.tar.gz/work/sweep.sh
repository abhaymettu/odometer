#!/bin/bash
# sweep.sh tableentry seed share g1 g2 ... ; 4 at a time
T=$1; S=$2; SH=$3; shift 3
printf "%s\n" "$@" | xargs -P 4 -I{} sh -c "python work/gb.py gate $T $S work/{}/train.py $SH 2>&1 | grep -v '^gate steps'"

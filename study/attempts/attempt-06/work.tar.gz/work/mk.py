import sys,re,os
# mk.py src dst NAME=VALUE ...
s=open(sys.argv[1]).read()
for kv in sys.argv[3:]:
    k,v=kv.split('=',1)
    s,n=re.subn(r'^%s = .*$'%k,lambda m:'%s = %s'%(k,v),s,flags=re.M); assert n==1,k
os.makedirs(os.path.dirname(sys.argv[2]),exist_ok=True); open(sys.argv[2],'w').write(s)

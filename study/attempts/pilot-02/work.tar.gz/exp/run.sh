#!/bin/bash
# run.sh name seeds  -> runs exp/name.py on dev
cd /home/user/att/pilot-02
python verify.py exp/$1.py --split dev --seeds $2 --jobs ${3:-1} --out exp/$1-out.json > exp/$1.log 2>&1

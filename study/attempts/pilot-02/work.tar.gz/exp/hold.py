#!/usr/bin/env python3
# hold.py train entry.py seed dir            trains and keeps params in dir
# hold.py eval  entry.py seed dir [K=V ...]  scores on dev with constants overridden, printing bpb; train params stay
import sys,subprocess,json,os,re,tempfile,pathlib,shutil
ROOT='/home/user/att/pilot-02'
sys.path.insert(0,ROOT)
env={"PATH":os.environ.get("PATH",""),**{v:"1" for v in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","VECLIB_MAXIMUM_THREADS","NUMEXPR_NUM_THREADS")}}
mode,entry,seed,d=sys.argv[1:5]
d=pathlib.Path(d).resolve(); entry=str(pathlib.Path(entry).resolve())
if mode=='train':
    d.mkdir(parents=True,exist_ok=True)
    import verify
    (d/'track.json').write_text(json.dumps(verify.TRACK))
    subprocess.run([sys.executable,'-I',ROOT+'/verify.py','--child-train',entry,seed,str(d)],cwd=d,env=env,check=True)
    print((d/'train.json').read_text())
else:
    s=open(entry).read()
    for kv in sys.argv[5:]:
        k,v=kv.split('=',1)
        s,n=re.subn(rf'^{k} = .*$', f'{k} = {v}', s, flags=re.M); assert n==1,k
    with tempfile.TemporaryDirectory() as t:
        t=pathlib.Path(t)
        (t/'e.py').write_text(s)
        for f in ('track.json','names.json'):
            shutil.copy(d/f,t/f)
        os.symlink(d/'params.npz',t/'params.npz')
        subprocess.run([sys.executable,'-I',ROOT+'/verify.py','--child-eval',str(t/'e.py'),seed,'dev',str(t)],cwd=t,env=env,check=True)
        r=json.loads((t/'eval.json').read_text())
    print(' '.join(sys.argv[5:]), r['bpb'], r['status'], int(r['eval_ticks_per_byte']), int(r['eval_seconds']),flush=True)

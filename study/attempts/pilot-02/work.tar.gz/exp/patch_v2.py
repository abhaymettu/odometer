s=open('v1.py').read()
s=s.replace('''ORDERS = (1, 2, 3, 4, 5, 6, 8, 10, 12)
ROWS = (256, 8191, 16381, 32749, 75989, 75989, 99991, 99991, 99991)
EMBEDS = (8, 8, 8, 8, 8, 8, 8, 8, 8)
EVERY = (1, 1, 1, 4, 4, 4, 4, 4, 4)
''','''ORDERS = (1, 2, 3, 4, 5, 6)
ROWS = (256, 8191, 16381, 32749, 60000, 60000)
EMBEDS = (8, 8, 8, 8, 8, 8)
EVERY = (1, 1, 1, 4, 4, 4)
COUNT_ORDERS = (6, 8, 10, 12)  # hashed (context, next byte) counts, gathered from the gradient of a sum of lookups
NARROW = (499979, 499979, 299993, 199999)  # kept slots per order
FOLD = (8, 16, 16, 16)  # wide slots per kept slot during counting
TAU = (8, 8, 8, 8)  # counts below this do not survive the fold
ALPHA = (30.0, 30.0, 30.0, 30.0)
DISC = (0.7, 0.8, 0.85, 0.85)
COUNT_FRAC = 0.25
COUNT_ROWS = 1024
COUNT_WINDOW = 512
COUNT_PAD = 12
MUL_CTX = 1000003
MUL_KEY = 739474771
MUL_NEXT = 1500450271
''')
s=s.replace('''def forward(params, x):
    z = od.concat([x[:, :PAD] * 0, x], 1)
    rows = order_rows(z)
    out = od.softmax(mix(params, rows), -1)
    eye = od.tril(od.ones((256, 256))) - od.tril(od.ones((256, 256)), -1)
    place = od.zeros((CLASSES, 256))
    for b in candidates():
        place = od.concat([place[: b % CLASSES], place[b % CLASSES : b % CLASSES + 1] + eye[b : b + 1], place[b % CLASSES + 1 :]], 0)
    p = out @ place + FLOOR
''','''def count_hashes(x, pad):
    """One integer tensor per count order: a hash of the n bytes ending at each position of x[:, pad:]."""
    T = x.shape[1]
    h = x[:, pad:] * 0
    out = []
    for n in range(1, max(COUNT_ORDERS) + 1):
        h = h * MUL_CTX + x[:, pad - n + 1 : T - n + 1] + 1
        if n in COUNT_ORDERS:
            out.append(h * MUL_KEY)
    return out


def count_all(data, stop):
    """Count (context, next byte) keys into wide tables, prune the rare ones, fold into the narrow tables kept."""
    tables = [od.param(od.zeros((n * f, 1))) for n, f in zip(NARROW, FOLD)]
    while od.used() < stop:
        x, y = data.batch(COUNT_ROWS, COUNT_WINDOW)
        code = (y[:, COUNT_PAD:] + 1) * MUL_NEXT
        total = None
        for i, h in enumerate(count_hashes(x, COUNT_PAD)):
            hits = od.sum(od.embedding(tables[i], (h + code) % (NARROW[i] * FOLD[i])))
            total = hits if total is None else total + hits
        total.backward()
    out = {}
    for i, t in enumerate(tables):
        c = t.grad.reshape(FOLD[i], NARROW[i])
        out[f"c{i}"] = od.param(od.sum(c * (c >= TAU[i]), 0).reshape(NARROW[i], 1))
    return out


def stage(p, c, a, d):
    total = od.sum(c, -1, keepdims=True)
    kinds = od.sum(c > 0.0, -1, keepdims=True)
    return (od.relu(c - d) + (kinds * d + a) * p) / (total + a)


def forward(params, x):
    B, T = x.shape
    z = od.concat([x[:, :PAD] * 0, x], 1)
    rows = order_rows(z)
    out = od.softmax(mix(params, rows), -1)
    eye = od.tril(od.ones((256, 256))) - od.tril(od.ones((256, 256)), -1)
    cand = candidates()
    C = len(cand)
    pick = od.zeros((CLASSES, C))
    for j, b in enumerate(cand):
        k = b % CLASSES
        cell = od.concat([od.zeros((1, j)), od.ones((1, 1)), od.zeros((1, C - j - 1))], 1)
        pick = od.concat([pick[:k], pick[k : k + 1] + cell, pick[k + 1 :]], 0)
    pc = out @ pick
    one = x[:1, :1] * 0
    codes = od.concat([(one + b + 1) * MUL_NEXT for b in cand], 1).reshape(1, 1, C)
    prev = None
    for i, h in enumerate(count_hashes(z, PAD)):
        if COUNT_ORDERS[i] > PAD:
            continue
        slot = (h.reshape(B, T, 1) + codes) % NARROW[i]
        c = od.embedding(params[f"c{i}"], slot).reshape(B, T, C)
        c = c if prev is None else od.minimum(c, prev)
        prev = c
        pc = stage(pc, c, ALPHA[i], DISC[i])
    place = od.concat([eye[b : b + 1] for b in cand], 0)
    p = pc @ place + FLOOR
''')
s=s.replace('''def train(data):
    p = init_params()
''','''def train(data):
    counts = count_all(data, od.budget() * COUNT_FRAC)
    p = init_params()
''')
s=s.replace('''    return p
E''','')
assert s.rstrip().endswith('return p')
s=s.rstrip()[:-len('return p')]+'return p | counts\n'
s=s.replace('''def count_hashes''','''def count_hashes''')
open('v2.py','w').write(s)

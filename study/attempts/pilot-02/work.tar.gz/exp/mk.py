import re,sys,json
# usage: mk.py base out NAME=VALUE ...
base,out=sys.argv[1:3]
s=open(base).read()
for kv in sys.argv[3:]:
    k,v=kv.split('=',1)
    s,n=re.subn(rf'^{k} = .*$', f'{k} = {v}', s, flags=re.M)
    assert n==1,k
open(out,'w').write(s)

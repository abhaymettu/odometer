"""Hashed context mixing in the PAQ tradition, trained by gradient descent, with word contexts and a cheaper output.

Extends the record entry (mixer: Mahoney's PAQ/lpaq, fastText hashing, AdaGrad tables, in-window PPM backoff after
Cleary & Witten and Teh). Changes: bytes are folded by b % CLASSES into a smaller softmax, which cuts the head and the
cross entropy roughly in half; small tables update more often than big ones; tables have per-context widths; and the
PAQ8 style word contexts join the byte orders.
"""

import math

import odometer as od

ORDERS = (1, 2, 3, 4, 5, 6)
ROWS = (256, 8191, 16381, 32749, 60000, 60000)
EMBEDS = (8, 8, 8, 8, 8, 8)
EVERY = (1, 1, 1, 4, 4, 4)
COUNT_ORDERS = (6, 8, 10, 12)  # hashed (context, next byte) counts, gathered from the gradient of a sum of lookups
NARROW = (299993, 299993, 199999, 149993)
FOLD = (8, 16, 16, 16)  # wide slots per kept slot during counting
TAU = (8, 8, 8, 8)  # counts below this do not survive the fold
ALPHA = (30.0, 30.0, 30.0, 30.0)
DISC = (0.7, 0.8, 0.85, 0.85)
COUNT_FRAC = 0.25
COUNT_ROWS = 1024
COUNT_WINDOW = 512
COUNT_PAD = 12
MUL_CTX = 1000003
MUL_KEY = 739474771
MUL_NEXT = 1500450271
WORD_ROWS = (40000, 60000, 60000)
WORD_EMBEDS = (8, 8, 8)
WORD_EVERY = (4, 4, 4)
HIDDEN = 64
BATCH = 64
WINDOW = 64
LR_TABLE = 0.25
LR_MIX = 6e-3
PAD = 24
LOCAL = ((2, 35.0, 0.6), (3, 6.0, 0.6), (5, 2.0, 0.6))
WARMUP = 0.02
HASH_A = 16777619
HASH_B = 2654435761 % (1 << 31)
CLASSES = 130
FLOOR = 1e-7


def candidates():
    """The bytes the softmax can name. Every other byte gets FLOOR at eval, and its class at train."""
    return (0, 10, *range(32, 96), *range(97, 123), 128, 147, 148, 152, 153, 156, 157, 226)


def init_params():
    rows, dims = ROWS + WORD_ROWS, EMBEDS + WORD_EMBEDS
    p = {f"t{k}": od.zeros((r, d)) for k, (r, d) in enumerate(zip(rows, dims))}
    n = sum(dims)
    p["up"] = od.randn((n, HIDDEN), 1.0 / math.sqrt(n))
    p["bias"] = od.ones((1, 1, HIDDEN))
    p["head"] = od.zeros((HIDDEN, CLASSES))
    return {k: od.param(v) for k, v in p.items()}


def is_letter(b):
    """1 for bytes from 65 up, which is letters and UTF-8 in this corpus, 0 for the rest."""
    return (b // 65 + 3) // 4


def word_rows(z):
    """Hashes of the current word's prefix and of the words before it, scanning each row once."""
    B, T = z.shape
    w = z[:, :1] * 0
    prev1, prev2 = w, w
    cols = [[] for r in WORD_ROWS]
    for t in range(T):
        b = z[:, t : t + 1]
        keep = is_letter(b)
        ended = 1 - keep
        moved = ended * ((w % 1073741824 + 1073741823) // 1073741824)
        prev2 = prev2 * (1 - moved) + prev1 * moved
        prev1 = prev1 * (1 - moved) + w * moved
        w = (w * HASH_A + b + 1) * keep
        if t >= PAD:
            c = [w, w * 31 + prev1 * HASH_B, w * 37 + prev1 * HASH_B + prev2 * 40503]
            for i in range(len(WORD_ROWS)):
                cols[i].append(c[i])
    k = len(ROWS)
    return [(od.concat(col, 1) * HASH_B + k + i) % WORD_ROWS[i] for i, col in enumerate(cols)]


def order_rows(z):
    """z holds PAD bytes of history, then the positions to predict. One tensor of table rows per context, (B, T)."""
    T = z.shape[1]
    h = z[:, PAD:] * 0
    out = []
    for n in range(1, max(ORDERS) + 1):
        h = h * HASH_A + z[:, PAD - n + 1 : T - n + 1]
        for i, order in enumerate(ORDERS):
            if order == n:
                out.append(h if n == 1 else (h * HASH_B + i) % ROWS[i])
    return out + (word_rows(z) if WORD_ROWS else [])


def mix(p, rows):
    parts = [od.embedding(p[f"t{k}"], r) for k, r in enumerate(rows)]
    a = od.relu(od.concat(parts, -1) @ p["up"] + p["bias"])
    return (a * a) @ p["head"]


def window_votes(rows, x):
    """For each position and byte, how often this window already saw that byte follow this context. Causal: s < t."""
    B, T = x.shape
    d = rows.reshape(B, T, 1) - rows.reshape(B, 1, T)
    same = od.tril((d >= 0) * (d <= 0), -1)
    eye = od.tril(od.ones((256, 256))) - od.tril(od.ones((256, 256)), -1)
    follows = od.embedding(eye, x[:, 1:])
    return same[:, :, : T - 1] @ follows


def count_hashes(x, pad):
    """One integer tensor per count order: a hash of the n bytes ending at each position of x[:, pad:]."""
    T = x.shape[1]
    h = x[:, pad:] * 0
    out = []
    for n in range(1, max(COUNT_ORDERS) + 1):
        h = h * MUL_CTX + x[:, pad - n + 1 : T - n + 1] + 1
        if n in COUNT_ORDERS:
            out.append(h * MUL_KEY)
    return out


def count_all(data, stop):
    """Count (context, next byte) keys into wide tables, prune the rare ones, fold into the narrow tables kept."""
    tables = [od.param(od.zeros((n * f, 1))) for n, f in zip(NARROW, FOLD)]
    while od.used() < stop:
        x, y = data.batch(COUNT_ROWS, COUNT_WINDOW)
        code = (y[:, COUNT_PAD:] + 1) * MUL_NEXT
        total = None
        for i, h in enumerate(count_hashes(x, COUNT_PAD)):
            hits = od.sum(od.embedding(tables[i], (h + code) % (NARROW[i] * FOLD[i])))
            total = hits if total is None else total + hits
        total.backward()
    out = {}
    for i, t in enumerate(tables):
        c = t.grad.reshape(FOLD[i], NARROW[i])
        out[f"c{i}"] = od.param(od.sum(c * (c >= TAU[i]), 0).reshape(NARROW[i], 1))
    return out


def stage(p, c, a, d):
    total = od.sum(c, -1, keepdims=True)
    kinds = od.sum(c > 0.0, -1, keepdims=True)
    return (od.relu(c - d) + (kinds * d + a) * p) / (total + a)


def forward(params, x):
    B, T = x.shape
    z = od.concat([x[:, :PAD] * 0, x], 1)
    rows = order_rows(z)
    out = od.softmax(mix(params, rows), -1)
    eye = od.tril(od.ones((256, 256))) - od.tril(od.ones((256, 256)), -1)
    cand = candidates()
    C = len(cand)
    pick = od.zeros((CLASSES, C))
    for j, b in enumerate(cand):
        k = b % CLASSES
        cell = od.concat([od.zeros((1, j)), od.ones((1, 1)), od.zeros((1, C - j - 1))], 1)
        pick = od.concat([pick[:k], pick[k : k + 1] + cell, pick[k + 1 :]], 0)
    pc = out @ pick
    one = x[:1, :1] * 0
    codes = od.concat([(one + b + 1) * MUL_NEXT for b in cand], 1).reshape(1, 1, C)
    prev = None
    for i, h in enumerate(count_hashes(z, PAD)):
        if COUNT_ORDERS[i] > PAD:
            continue
        slot = (h.reshape(B, T, 1) + codes) % NARROW[i]
        c = od.embedding(params[f"c{i}"], slot).reshape(B, T, C)
        c = c if prev is None else od.minimum(c, prev)
        prev = c
        pc = stage(pc, c, ALPHA[i], DISC[i])
    place = od.concat([eye[b : b + 1] for b in cand], 0)
    p = pc @ place + FLOOR
    for i, beta, disc in LOCAL:
        c = window_votes(rows[i], x)
        total = od.sum(c, -1, keepdims=True)
        kinds = od.sum(c > 0.0, -1, keepdims=True)
        p = (od.relu(c - disc) + (kinds * disc + beta) * p) / (total + beta)
    return od.log(p + 1e-12)


def train(data):
    counts = count_all(data, od.budget() * COUNT_FRAC)
    p = init_params()
    every = EVERY + WORD_EVERY
    tables = {f"t{k}": e for k, e in enumerate(every)}
    m = {k: od.zeros(v.shape) for k, v in p.items() if k not in tables}
    s = {k: od.full(v.shape, 1e-8) for k, v in p.items()}
    start, span = od.used(), od.remaining()
    worst, step = 0, 0
    while od.remaining() > 2 * worst + 1_000_000:
        before = od.used()
        frac = (before - start) / span
        sched = frac / WARMUP if frac < WARMUP else 0.5 * (1 + math.cos(math.pi * (frac - WARMUP) / (1 - WARMUP)))
        z, y = data.batch(BATCH, WINDOW + PAD)
        od.cross_entropy(mix(p, order_rows(z)), y[:, PAD:] % CLASSES).backward()
        step += 1
        c1, c2 = LR_MIX * sched / (1 - 0.9**step), 1 / (1 - 0.99**step)
        lrt = LR_TABLE * min(1.0, frac / WARMUP)
        for k, v in p.items():
            g = v.grad
            if k in tables:
                if step % tables[k]:
                    continue
                s[k] = s[k] + g * g
                v.update(v - g * od.rsqrt(s[k]) * lrt)
            else:
                m[k] = m[k] * 0.9 + g * 0.1
                s[k] = s[k] * 0.99 + g * g * 0.01
                v.update(v - m[k] * od.rsqrt(s[k] * c2 + 1e-16) * c1)
            v.grad = None
        worst = max(worst, od.used() - before)
    return p | counts

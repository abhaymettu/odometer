import sys,re
src,dst,every=sys.argv[1:4]
s=open(src).read()
new='''"""Hashed context mixing in the PAQ tradition, trained by gradient descent, with a cheaper output and lazy big tables.

Extends the record entry (mixer: Mahoney's PAQ/lpaq, fastText hashing, AdaGrad tables, in-window PPM backoff after
Cleary & Witten and Teh). Bytes are folded by b % CLASSES into a smaller softmax, which about halves the price of the
head and the cross entropy. Tables update on a schedule set by their size (EVERY), since a dense update costs about
2 ticks per float whatever it touches. The saved ticks buy more training bytes. The word-context code is switched off
(WORD_ROWS is empty): word contexts scored worse in testing at this budget.
"""'''
s2,n=re.subn(r'^""".*?"""',lambda m:new,s,count=1,flags=re.S); assert n==1
open(dst,'w').write(s2)

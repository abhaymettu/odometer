"""Generate variants of the current entry by textual patching. usage: mk.py name KEY=VAL ... (KEY are module constants)"""
import re, sys
src = open('/home/user/att/attempt-03/.tmp/w/word.py').read()
name, *kv = sys.argv[1:]
for s in kv:
    k, v = s.split('=', 1)
    src, n = re.subn(rf'^{k} = .*$', f'{k} = {v}', src, flags=re.M)
    assert n == 1, k
open(f'/home/user/att/attempt-03/.tmp/w/v/{name}.py', 'w').write(src)

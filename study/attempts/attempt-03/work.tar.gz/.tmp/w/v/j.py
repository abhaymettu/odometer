"""Hashed context mixing trained by gradient descent, then a learned in-window mixer in place of hand-set PPM constants.

Extends the record entry (Mahoney's PAQ/lpaq, fastText hashing, AdaGrad tables, in-window PPM backoff after Cleary &
Witten and Teh). The table model and its training are unchanged except that it now gets 92% of the budget.

The last 8% of the budget fits a small gate with the tables frozen. The record's five fixed in-window stages become six
(order 1 added), and each stage's concentration and discount become functions of the position: a small network on the
vote totals, distinct-byte counts, top-vote share and the softmax's entropy and peak, plus an offset per last byte. A
final gated pair of weights mixes the softmax and the last stage as logits. The constants in LOCAL and MIXW are starting
points only; they were set from the average gate outputs on training batches so the gate spends its steps on what varies.

Votes now run over the 76 softmax classes rather than 256 bytes, and the causal mask is built once per call, which halves
the eval price per byte even with the sixth stage. Rare bytes vote for the class they share. The gate trains on 256-byte
windows at three steps per batch, since the votes cost more than the steps.

Measured and dropped: thinner table gradients for low orders, 6-float rows, stages at orders 0, 5 and 10,
logit weights on every intermediate stage, 128-byte gate windows, five steps per batch.
"""

import math

import odometer as od

ORDERS = (1, 2, 3, 4, 5, 6, 8, 10, 12)
ROWS = (256, 8191, 16381, 32749, 75989, 75989, 104003, 104003, 104003)
EMBEDS = (8, 8, 8, 8, 8, 8, 8, 8, 8)
WEMBEDS = ()
GE = (4, 4, 4, 2, 1, 1, 1, 1, 1)
WGE = ()
EVERY = (4, 4, 4, 4, 8, 8, 16, 16, 16)
WORDS = ()
WROWS = ()
WEVERY = ()
HIDDEN = 64
BATCH = 128
WINDOW = 64
LR_TABLE = 0.3
LR_TAIL = 0.4  # the table rate falls linearly to this fraction of LR_TABLE over the run
LR_MIX = 1.2e-2
PAD = 40
LOCAL = ((1, 100.0, 0.02), (2, 22.7, 0.022), (3, 7.0, 0.343), (4, 5.5, 0.226), (6, 0.85, 0.684), (16, 0.39, 0.6))  # (order, concentration, discount) before the gates
MIXW = (0.51, 0.55)  # logit weight of the softmax and of each stage before the gates  # (order, concentration, discount)
WARMUP = 0.02
HASH_A = 16777619
WK1 = 1000003
WK2 = 998244353
HASH_B = 2654435761 % (1 << 31)
CLASSES = 76
FLOOR = 1e-7
COLD_EVERY = 16
GATE = 16
GATE_BATCH = 4
GATE_T = 256
GATE_LR = 0.02
GATE_SHARE = 0.08
EVAL_T = 512


def candidates():
    """The bytes the softmax can name. Every other byte gets FLOOR at eval, and shares a class at train."""
    return (0, 10, 32, 33, 34, 39, 44, 45, 46, 51, 52, 53, 54, 56, 57, 58, 59, 63, *range(65, 91), *range(97, 123), 128, 153, 156, 157, 226)


def class_of(b):
    """Softmax class of a candidate byte."""
    if b < 32:
        return b // 10
    if b < 65:
        return 2 + (b - 32) % 16
    if b < 97:
        return b - 47
    return b - 53 if b < 128 else 70 + (b - 128) % 6


def fold(y):
    """The same map on a tensor. Rare bytes share a class with a common one and train it, which costs almost nothing."""
    hi = y // 128
    ge32 = (y // 32 + 3) // 4
    ge65 = (y // 65 + 3) // 4
    ge97 = (y // 97 + 1) // 2
    low = (1 - ge32) * (y // 10) + (ge32 - ge65) * ((y - 32) % 16 + 2) + (ge65 - ge97) * (y - 47) + ge97 * (y - 53)
    return low * (1 - hi) + ((y - 128) % 6 + 70) * hi


def init_params():
    p = {f"t{k}": od.zeros((r, (EMBEDS + WEMBEDS)[k])) for k, r in enumerate(ROWS + WROWS)}
    n = sum(EMBEDS + WEMBEDS)
    p["up"] = od.randn((n, HIDDEN), 1.0 / math.sqrt(n))
    p["bias"] = od.ones((1, 1, HIDDEN))
    p["head"] = od.zeros((HIDDEN, CLASSES))
    return {k: od.param(v) for k, v in p.items()}


def order_rows(z):
    """z holds PAD bytes of history, then the positions to predict. One tensor of table rows per context, (B, T)."""
    T = z.shape[1]
    h = z[:, PAD:] * 0
    out = []
    for n in range(1, max(ORDERS) + 1):
        h = h * HASH_A + z[:, PAD - n + 1 : T - n + 1]
        for i, order in enumerate(ORDERS):
            if order == n:
                out.append(h if n == 1 else (h * HASH_B + i) % ROWS[i])
    return out + word_rows(z)


def carry(event, val):
    """Latest value of val where event is 1, at or before each position. Drops 15 positions."""
    v, e = event * val, event
    for s in (1, 2, 4, 8):
        off = 1 - e[:, s:]
        v, e = v[:, s:] + off * v[:, :-s], e[:, s:] + off * e[:, :-s]
    return v


def word_rows(z):
    """Hashes of the current word's prefix and the one or two words before it, folded to ignore case."""
    if not WORDS:
        return []
    T = z.shape[1] - PAD
    is_l = (z // 65 + 3) // 4
    h, run = is_l * (z % 32), is_l
    m = HASH_A
    for s in (1, 2, 4):
        h = h[:, s:] + run[:, s:] * h[:, :-s] * m
        run = run[:, s:] * run[:, :-s]
        m = m * m % (1 << 31) | 1
    # h starts 7 later than z
    lz, lb = is_l[:, 7:], z[:, 7:]
    event = (1 - lz[:, 1:]) * lz[:, :-1]
    p1 = carry(event, h[:, :-1])  # 7 + 1 + 15 = 23 dropped
    p2 = carry(event[:, 15:][:, 1:], p1[:, :-1])  # 23 + 1 + 15 = 39
    cur = h[:, -T:] * 31 + lb[:, -T:]
    out = []
    for i, w in enumerate(WORDS):
        c = cur + p1[:, -T:] * WK1
        if w == "cur":
            c = cur
        if w == "tri":
            c = c + p2[:, -T:] * WK2
        if w == "skip":
            c = lb[:, -T:] + p1[:, -T:] * WK1 + p2[:, -T:] * WK2
        out.append((c * HASH_B + i + 17) % WROWS[i])
    return out


def history_masks(T):
    """Per context, 0 at positions whose context reaches back before the start of the window, else 1. (1, T, 1)."""
    return [od.concat([od.zeros((1, n - 1, 1)), od.ones((1, T - n + 1, 1))], 1) for n in ORDERS] + [od.ones((1, T, 1)) for w in WORDS]


def mix(p, rows, masks=None, step=0):
    ge = GE + WGE
    parts = [od.embedding(p[f"t{k}"] if step % ge[k] == 0 else p[f"t{k}"].detach(), r) for k, r in enumerate(rows)]
    if masks:
        parts = [e * m for e, m in zip(parts, masks)]
    a = od.relu(od.concat(parts, -1) @ p["up"] + p["bias"])
    return (a * a) @ p["head"]


def raw_hashes(z):
    """Unreduced hash per in-window order, since a table's modulus would add false matches. (B, T)."""
    T = z.shape[1]
    h = z[:, PAD:] * 0
    out = {}
    for n in range(1, max(i for i, b, d in LOCAL) + 1):
        h = h * HASH_A + z[:, PAD - n + 1 : T - n + 1]
        out[n] = h
    return out


def identity(n):
    return od.tril(od.ones((n, n))) - od.tril(od.ones((n, n)), -1)


def local_stats(z, x):
    """Per in-window order: votes per class, their total, and how many classes have a vote."""
    B, T = x.shape
    raw = raw_hashes(z)
    mask = od.tril(od.ones((1, T, T)), -1)
    follows = od.embedding(identity(CLASSES), fold(x[:, 1:]))
    out = []
    for n, beta, disc in LOCAL:
        d = raw[n].reshape(B, T, 1) - raw[n].reshape(B, 1, T)
        same = (d >= 0) * (d <= 0) * mask
        c = same[:, :, : T - 1] @ follows
        out.append((c, od.sum(c, -1, keepdims=True), od.sum(c > 0.0, -1, keepdims=True)))
    return out


def base_probs(p, z, x):
    return od.softmax(mix(p, order_rows(z), history_masks(x.shape[1])), -1)


def features(p0, stats):
    ent = od.sum(p0 * od.log(p0 + 1e-9), -1, keepdims=True) * -0.25
    top = od.max(p0, -1, keepdims=True)
    parts = [ent, top, od.ones((1, 1, 1)) + p0[:, :, :1] * 0.0]
    for c, t, k in stats:
        seen = t > 0.0
        parts += [od.log(t + 1.0) * 0.25, od.log(k + 1.0) * 0.5, seen, seen * (k <= 1.0), od.max(c, -1, keepdims=True) / (t + 1.0)]
    return od.concat(parts, -1)


def gate_params():
    n = len(LOCAL)
    nf = 3 + 5 * n
    nout = 2 * n + 2
    q = {"g1": od.randn((nf, GATE), 1.0 / math.sqrt(nf)), "g2": od.zeros((GATE, nout)), "g3": od.zeros((nf, nout)), "g4": od.zeros((256, nout))}
    return {k: od.param(v) for k, v in q.items()}


def gates(q, f, x):
    return f @ q["g3"] + od.relu(f @ q["g1"]) @ q["g2"] + od.embedding(q["g4"], x)


def blend(q, p0, stats, x):
    """Back off through the in-window orders with learned concentrations and discounts, then mix all stages as logits."""
    n = len(LOCAL)
    f = features(p0, stats)
    out = gates(q, f, x)
    p = p0
    for i, (order, beta, disc) in enumerate(LOCAL):
        c, t, k = stats[i]
        b = od.exp(out[:, :, i : i + 1]) * beta
        d = od.sigmoid(out[:, :, n + i : n + i + 1] + math.log(disc / (1 - disc)))
        p = (od.relu(c - d) + (k * d + b) * p) / (t + b)
    a0 = out[:, :, 2 * n : 2 * n + 1] + MIXW[0]
    a1 = out[:, :, 2 * n + 1 : 2 * n + 2] + MIXW[1]
    return od.log(p0 + 1e-9) * a0 + od.log(p + 1e-9) * a1


def forward(params, x):
    z = od.concat([x[:, :PAD] * 0, x], 1)
    p0 = base_probs(params, z, x)
    out = od.softmax(blend(params, p0, local_stats(z, x), x), -1)
    eye = identity(256)
    place = od.zeros((CLASSES, 256))
    for b in candidates():
        c = class_of(b)
        place = od.concat([place[:c], place[c : c + 1] + eye[b : b + 1], place[c + 1 :]], 0)
    return od.log(out @ place + FLOOR)


def fit_gate(p, data):
    q = gate_params()
    m = {k: od.zeros(v.shape) for k, v in q.items()}
    s = {k: od.full(v.shape, 1e-8) for k, v in q.items()}
    start, span = od.used(), od.remaining()
    worst, step = 0, 0
    while od.remaining() > 2 * worst + 1_000_000:
        before = od.used()
        frac = (before - start) / span
        z, y = data.batch(GATE_BATCH, GATE_T + PAD)
        x = z[:, PAD:]
        with od.no_grad():
            p0 = base_probs(p, z, x)
            stats = local_stats(z, x)
        for again in range(3):
            od.cross_entropy(blend(q, p0, stats, x), fold(y[:, PAD:])).backward()
            step += 1
            c1, c2 = GATE_LR * 0.5 * (1 + math.cos(math.pi * frac)) / (1 - 0.9**step), 1 / (1 - 0.99**step)
            for k, v in q.items():
                g = v.grad
                m[k] = m[k] * 0.9 + g * 0.1
                s[k] = s[k] * 0.99 + g * g * 0.01
                v.update(v - m[k] * od.rsqrt(s[k] * c2 + 1e-16) * c1)
                v.grad = None
        worst = max(worst, od.used() - before)
    return q


def fit_tables(data, stop):
    p = init_params()
    tables = {f"t{k}": e for k, e in enumerate(EVERY + WEVERY)}
    m = {k: od.zeros(v.shape) for k, v in p.items() if k not in tables}
    s = {k: od.full(v.shape, 1e-8) for k, v in p.items()}
    cold = history_masks(WINDOW)
    start, span = od.used(), od.remaining() - stop
    worst, step = 0, 0
    while od.remaining() - stop > 2 * worst + 1_000_000:
        before = od.used()
        frac = (before - start) / span
        sched = frac / WARMUP if frac < WARMUP else 0.5 * (1 + math.cos(math.pi * (frac - WARMUP) / (1 - WARMUP)))
        z, y = data.batch(BATCH, WINDOW + PAD)
        step += 1
        masks = cold if step % COLD_EVERY == 0 else None
        od.cross_entropy(mix(p, order_rows(z), masks, step), fold(y[:, PAD:])).backward()
        c1, c2 = LR_MIX * sched / (1 - 0.9**step), 1 / (1 - 0.99**step)
        lrt = LR_TABLE * min(1.0, frac / WARMUP) * (1 - (1 - LR_TAIL) * frac)
        for k, v in p.items():
            g = v.grad
            if k in tables:
                if step % tables[k] or g is None:
                    continue
                s[k] = s[k] + g * g
                v.update(v - g * od.rsqrt(s[k]) * lrt)
            else:
                m[k] = m[k] * 0.9 + g * 0.1
                s[k] = s[k] * 0.99 + g * g * 0.01
                v.update(v - m[k] * od.rsqrt(s[k] * c2 + 1e-16) * c1)
            v.grad = None
        worst = max(worst, od.used() - before)
    return p


def train(data):
    p = fit_tables(data, od.remaining() * GATE_SHARE)
    return p | fit_gate(p, data)

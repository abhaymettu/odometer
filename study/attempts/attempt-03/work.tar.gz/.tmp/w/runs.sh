#!/bin/bash
# usage: runs.sh windows file seed1 seed2 ... ; one file on several seeds in parallel
cd /home/user/att/attempt-03/.tmp/w
w=$1; f=$2; shift 2
for s in "$@"; do python q.py $f $s $w >> results.txt 2>&1 & done
wait
date >> results.txt

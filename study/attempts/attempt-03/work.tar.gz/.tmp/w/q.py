"""Quick harness: python q.py entry seed [windows]. Runs verify.run_seed with a smaller eval set, prints one line."""
import sys, pathlib, json, time
sys.path.insert(0, '/home/user/att/attempt-03')
import verify
entry, seed = pathlib.Path(sys.argv[1]).resolve(), int(sys.argv[2])
win = int(sys.argv[3]) if len(sys.argv) > 3 else 256
tr = {**verify.TRACK, "eval_windows": win}
p = verify.static_problems(entry.read_text(), tr)
if p: print(entry, p); sys.exit(2)
logs = pathlib.Path('/home/user/att/attempt-03/.tmp/w/logs'); logs.mkdir(exist_ok=True)
t=time.time()
r = verify.run_seed(entry, seed, 'dev', tr, logs)
print(entry.stem, seed, 'bpb', r.get('bpb'), r['status'][:200], 'tt', round(r.get('train_seconds',0)), 'et', round(r.get('eval_seconds',0)), 'ticks/b', round(r.get('eval_ticks_per_byte',0)), 'lines', r.get('train_python_lines'), 'params', r.get('params'), 'rss', round(r.get('peak_rss_mb',0)), flush=True)

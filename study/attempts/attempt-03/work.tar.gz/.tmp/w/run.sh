#!/bin/bash
# usage: run.sh seed windows path1 path2 ... ; runs all in parallel, appends to results.txt
cd /home/user/att/attempt-03/.tmp/w
s=$1; w=$2; shift 2
for f in "$@"; do python q.py $f $s $w >> results.txt 2>&1 & done
wait
date >> results.txt

"""dev harness: train tables only, cache them."""
import sys, os, json, pathlib, time
for v in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS"): os.environ[v]="1"
ROOT=pathlib.Path("/home/user/att/attempt-05"); sys.path.insert(0,str(ROOT))
import numpy as np, verify, odometer as od
from odometer import _data,_engine
entry,seed,out=sys.argv[1],int(sys.argv[2]),sys.argv[3]
_engine._M.reset(verify.TRACK["train_budget"],seed)
data=_data.TrainData()
m=verify.load_entry(entry,verify.TRACK)
t=time.time()
p=m.fit_tables(data,od.remaining()*m.GATE_SHARE)
np.savez(out,**{k:v._d for k,v in p.items()})
print("cached",out,_engine._M.used,time.time()-t,flush=True)

"""fit gate at a big budget on cached tables (train data only) and print the mean gate output, to re-centre constants"""
import sys, os, pathlib
for v in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS"): os.environ[v]="1"
ROOT=pathlib.Path("/home/user/att/attempt-05"); sys.path.insert(0,str(ROOT))
import numpy as np, verify, odometer as od
from odometer import _data,_engine
entry,cache,seed,share=sys.argv[1],sys.argv[2],int(sys.argv[3]),float(sys.argv[4])
c=np.load(cache); B=verify.TRACK["train_budget"]
m=verify.load_entry(entry,verify.TRACK)
_engine._M.reset(B,seed+5000); _engine._M.used=int(B*(1-share))
data=_data.TrainData()
p={k:od.Tensor(np.array(c[k])) for k in c.files}
q=m.fit_gate(p,data)
np.savez(sys.argv[5],**{k:v._d for k,v in q.items()})
_engine._M.reset(None,seed+6000)
outs=[]
n=len(m.LOCAL)
for i in range(12):
    z,y=data.batch(2,512+m.PAD); x=z[:,m.PAD:]
    with od.no_grad():
        p0=m.base_probs(p,z,x); st=m.local_stats(z,x); f=m.features(p0,st); o=m.gates(q,f,x)
    outs.append(o._d.reshape(-1,o.shape[-1]))
o=np.concatenate(outs); mu=o.mean(0); sd=o.std(0)
print("mean",np.round(mu,3).tolist()); print("sd",np.round(sd,3).tolist())
new=[]
for i,(ord_,b,d) in enumerate(m.LOCAL):
    nb=float(np.exp(mu[i])*b); nd=float(1/(1+np.exp(-(mu[n+i]+np.log(d/(1-d))))))
    new.append((ord_,round(nb,3),round(nd,3)))
print("LOCAL =",tuple(new)); print("MIXW =",(round(float(mu[2*n]+m.MIXW[0]),3),round(float(mu[2*n+1]+m.MIXW[1]),3)),flush=True)

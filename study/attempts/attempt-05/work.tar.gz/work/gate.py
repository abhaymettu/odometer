"""dev harness: gate stage + eval from cached tables. usage: gate.py entry cache.npz seed split"""
import sys, os, json, pathlib, time, tempfile
for v in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS"): os.environ[v]="1"
ROOT=pathlib.Path("/home/user/att/attempt-05"); sys.path.insert(0,str(ROOT))
import numpy as np, verify, odometer as od, subprocess
from odometer import _data,_engine
entry,cache,seed=sys.argv[1],sys.argv[2],int(sys.argv[3])
entry=str(pathlib.Path(entry).resolve())
c=np.load(cache)
B=verify.TRACK["train_budget"]
m=verify.load_entry(entry,verify.TRACK)
_engine._M.reset(B,seed+1000)
_engine._M.used=int(B*(1-getattr(m,"GATE_SHARE")))
data=_data.TrainData()
p={k:od.Tensor(np.array(c[k])) for k in c.files}
t=time.time()
q=m.fit_gate(p,data)
params=p|q
tt=time.time()-t
with tempfile.TemporaryDirectory() as tmp:
    tmp=pathlib.Path(tmp)
    (tmp/"track.json").write_text(json.dumps(verify.TRACK))
    np.savez(tmp/"params.npz",**{f"p{i}":v._d for i,v in enumerate(params.values())})
    (tmp/"names.json").write_text(json.dumps(list(params)))
    r=subprocess.run([sys.executable,"-I",str(ROOT/"verify.py"),"--child-eval",entry,str(seed),"dev",str(tmp)],cwd=tmp,env={"PATH":os.environ["PATH"],"OMP_NUM_THREADS":"1","OPENBLAS_NUM_THREADS":"1"},capture_output=True,text=True)
    if not (tmp/"eval.json").exists(): print(r.stdout,r.stderr)
    e=json.loads((tmp/"eval.json").read_text())
print(pathlib.Path(entry).parent.name,cache,f"gate {tt:.0f}s",e["status"],e["bpb"],f"ticks/b {e['eval_ticks_per_byte']:.0f} evals {e['eval_seconds']:.0f}s lines {e['eval_python_lines']}",flush=True)

import sys
base=open('base/train.py').read()
def gm(s):
    s=s.replace("nout = 2 * n + 2\n","nout = 3 * n + 2\n")
    s=s.replace("""    p = p0
    for i, (order, beta, disc) in enumerate(LOCAL):""","""    p = p0
    tap = od.log(p0 + 1e-9) * 0.0
    for i, (order, beta, disc) in enumerate(LOCAL):""")
    s=s.replace("""        p = (od.relu(c - d) + (k * d + b) * p) / (t + b)
""","""        p = (od.relu(c - d) + (k * d + b) * p) / (t + b)
        tap = tap + od.log(p + 1e-9) * out[:, :, 2 * n + 2 + i : 2 * n + 3 + i]
""")
    s=s.replace("return od.log(p0 + 1e-9) * a0 + od.log(p + 1e-9) * a1","return od.log(p0 + 1e-9) * a0 + od.log(p + 1e-9) * a1 + tap")
    return s
def t512(s): return s.replace("GATE_BATCH = 4\nGATE_T = 256","GATE_BATCH = 2\nGATE_T = 512")
def lo(s): return s.replace("(4, 5.5, 0.226), (102, 3.0, 0.4), (6, 0.85, 0.684), (16, 0.39, 0.6))","(4, 5.5, 0.226), (102, 3.0, 0.4), (5, 2.0, 0.5), (6, 0.85, 0.684), (103, 1.0, 0.5), (8, 0.6, 0.6), (16, 0.39, 0.6))")
open('gm/train.py','w').write(gm(base))
open('t512/train.py','w').write(t512(base))
open('lo/train.py','w').write(lo(base))
open('gm8/train.py','w').write(gm(t512(base)))
import re,os
def share(s,x): return s.replace("GATE_SHARE = 0.08","GATE_SHARE = %s"%x)
for name,s in {"t16":share(t512(base),0.16),"t32":share(t512(base),0.32),"gm32":share(gm(t512(base)),0.32),"lo32":share(lo(t512(base)),0.32)}.items():
    os.makedirs(name,exist_ok=True); open(name+'/train.py','w').write(s)
def lr(s,x): return s.replace("GATE_LR = 0.02","GATE_LR = %s"%x)
def rep(s,x): return s.replace("for again in range(3):","for again in range(%d):"%x)
T=t512(base)
for name,s in {"lr05":lr(T,0.05),"r6":rep(T,6),"lr05r6":lr(rep(T,6),0.05),"t64":share(T,0.64)}.items():
    os.makedirs(name,exist_ok=True); open(name+'/train.py','w').write(s)
for name,s in {"r1":rep(T,1),"r2":rep(T,2),"s16":share(T,0.16),"s24":share(T,0.24)}.items():
    os.makedirs(name,exist_ok=True); open(name+'/train.py','w').write(s)
def samp(s,x): return s.replace("SAMPLE = (4, 4, 4, 2, 1, 1, 1, 1, 1)","SAMPLE = %s"%(x,))
def b256(s): return s.replace("BATCH = 128","BATCH = 256").replace("EVERY = (1, 1, 1, 4, 8, 8, 16, 16, 16)","EVERY = (1, 1, 1, 2, 4, 4, 8, 8, 8)")
def o8(s):
    return (s.replace("ORDERS = (1, 2, 3, 4, 5, 6, 8, 10, 12)","ORDERS = (1, 2, 3, 4, 5, 7, 9, 12)")
     .replace("ROWS = (256, 8191, 16381, 32749, 75989, 75989, 104003, 104003, 104003)","ROWS = (256, 8191, 16381, 32749, 89989, 113989, 129971, 129971)")
     .replace("EVERY = (1, 1, 1, 4, 8, 8, 16, 16, 16)","EVERY = (1, 1, 1, 4, 8, 8, 16, 16)")
     .replace("SAMPLE = (4, 4, 4, 2, 1, 1, 1, 1, 1)","SAMPLE = (4, 4, 4, 2, 1, 1, 1, 1)"))
for name,s in {"sa":samp(T,(8,8,4,2,2,2,1,1,1)),"b256":b256(T),"o8":o8(T)}.items():
    os.makedirs(name,exist_ok=True); open(name+'/train.py','w').write(s)
def wc(s):
    i=s.index("LOCAL = ("); j=s.index("\n",i)
    s=s[:i]+"LOCAL = ((1, 62895.387, 0.006), (2, 96.589, 0.148), (3, 13.582, 0.3), (101, 10.624, 0.071), (4, 6.517, 0.148), (102, 1.497, 0.632), (6, 6.254, 0.407), (16, 0.038, 0.957))"+s[j:]
    return s.replace("MIXW = (0.51, 0.55)","MIXW = (0.634, 0.409)")
W=wc(T)
for name,s in {"wc":W,"wcr1":rep(W,1),"wcl1":lr(W,0.01),"wcl05":lr(W,0.005)}.items():
    os.makedirs(name,exist_ok=True); open(name+'/train.py','w').write(s)
def win(s,b,t,c): return s.replace("BATCH = 128","BATCH = %d"%b).replace("WINDOW = 64","WINDOW = %d"%t).replace("COLD_EVERY = 16","COLD_EVERY = %d"%c)
def ga(s):
    s=s.replace("""    s = {k: od.full(v.shape, 1e-8) for k, v in q.items()}
    start, span = od.used(), od.remaining()
    worst, step = 0, 0
    while od.remaining() > 2 * worst""","""    s = {k: od.full(v.shape, 1e-8) for k, v in q.items()}
    a = {k: v.detach() * 1.0 for k, v in q.items()}
    start, span = od.used(), od.remaining()
    worst, step = 0, 0
    while od.remaining() > 2 * worst""")
    s=s.replace("c1, c2 = GATE_LR * 0.5 * (1 + math.cos(math.pi * frac)) / (1 - 0.9**step)","c1, c2 = GATE_LR * (0.25 + 0.375 * (1 + math.cos(math.pi * frac))) / (1 - 0.9**step)")
    s=s.replace("""                v.update(v - m[k] * od.rsqrt(s[k] * c2 + 1e-16) * c1)
                v.grad = None
        worst = max(worst, od.used() - before)
    return q""","""                v.update(v - m[k] * od.rsqrt(s[k] * c2 + 1e-16) * c1)
                v.grad = None
                a[k] = a[k] * 0.98 + v.detach() * 0.02
        worst = max(worst, od.used() - before)
    return a""")
    return s
for name,s in {"w32":win(T,256,32,32),"w16":win(T,512,16,64),"ga":ga(T)}.items():
    os.makedirs(name,exist_ok=True); open(name+'/train.py','w').write(s)
def nomlp(s): return s.replace('return f @ q["g3"] + od.relu(f @ q["g1"]) @ q["g2"] + od.embedding(q["g4"], x)','return f @ q["g3"] + od.embedding(q["g4"], x)').replace('"g1": od.randn((nf, GATE), 1.0 / math.sqrt(nf)), "g2": od.zeros((GATE, nout)), ','')
def nog4(s): return s.replace('return f @ q["g3"] + od.relu(f @ q["g1"]) @ q["g2"] + od.embedding(q["g4"], x)','return f @ q["g3"] + od.relu(f @ q["g1"]) @ q["g2"]').replace(', "g4": od.zeros((256, nout))','')
def smallmlp(s): return s.replace("GATE = 16","GATE = 32")
def el(s):
    s=s.replace("ROWS = (256, 8191, 16381, 32749, 75989, 75989, 104003, 104003, 104003)\nEMBED = 8","ROWS = (256, 8191, 16381, 32749, 67993, 67993, 95989, 95989, 95989)\nEMBED = (8, 16, 16, 8, 8, 8, 8, 8, 8)")
    return s.replace('p = {f"t{k}": od.zeros((r, EMBED)) for k, r in enumerate(ROWS)}\n    n = EMBED * len(ROWS)','p = {f"t{k}": od.zeros((r, EMBED[k])) for k, r in enumerate(ROWS)}\n    n = sum(EMBED)')
for name,s in {"nomlp":nomlp(T),"nog4":nog4(T),"g32":smallmlp(T),"el":el(T)}.items():
    os.makedirs(name,exist_ok=True); open(name+'/train.py','w').write(s)
def ag(s,lr_=0.1,keys='("g4",)'):
    s=s.replace("""            for k, v in q.items():
                g = v.grad
                m[k] = m[k] * 0.9 + g * 0.1""","""            for k, v in q.items():
                g = v.grad
                if k in GATE_TABLES:
                    s[k] = s[k] + g * g
                    v.update(v - g * od.rsqrt(s[k]) * (GATE_TAB * (1 - 0.7 * frac)))
                    v.grad = None
                    continue
                m[k] = m[k] * 0.9 + g * 0.1""")
    return s.replace("GATE_SHARE = 0.08","GATE_SHARE = 0.08\nGATE_TAB = %s\nGATE_TABLES = %s"%(lr_,keys))
def g5(s,r=2039):
    s=s.replace('"g4": od.zeros((256, nout))}','"g4": od.zeros((256, nout)), "g5": od.zeros((%d, nout))}'%r)
    s=s.replace('od.embedding(q["g4"], x)\n','od.embedding(q["g4"], x) + od.embedding(q["g5"], (x * 251 + od.concat([x[:, :1] * 0, x[:, :-1]], 1)) %% %d)\n'%r)
    return s.replace("ROWS = (256, 8191, 16381, 32749, 75989, 75989, 104003, 104003, 104003)","ROWS = (256, 8191, 16381, 32749, 75989, 75989, 101999, 101999, 101999)")
for name,s in {"ag":ag(T),"g5":g5(T),"g5ag":ag(g5(T),0.1,'("g4", "g5")'),"nag":ag(nomlp(T))}.items():
    os.makedirs(name,exist_ok=True); open(name+'/train.py','w').write(s)
def norows(s): return s.replace("ROWS = (256, 8191, 16381, 32749, 75989, 75989, 101999, 101999, 101999)","ROWS = (256, 8191, 16381, 32749, 75989, 75989, 104003, 104003, 104003)")
for name,s in {"g5h":norows(g5(T)),"g5agh":norows(ag(g5(T),0.1,'("g4", "g5")')),"g5ag3":norows(ag(g5(T),0.03,'("g4", "g5")')),"ag3":ag(T,0.3)}.items():
    os.makedirs(name,exist_ok=True); open(name+'/train.py','w').write(s)
G=lambda l: norows(ag(g5(T),l,'("g4", "g5")'))
base256=base
for name,s in {"k2":G(0.2),"kn":nomlp(G(0.1)),"kt":G(0.1).replace("GATE_BATCH = 2\nGATE_T = 512","GATE_BATCH = 4\nGATE_T = 256"),"kr2":rep(G(0.1),2)}.items():
    os.makedirs(name,exist_ok=True); open(name+'/train.py','w').write(s)
K=G(0.1)
tt=lambda s:s.replace("GATE_BATCH = 2\nGATE_T = 512","GATE_BATCH = 4\nGATE_T = 256")
for name,s in {"m1":nomlp(rep(tt(K),2)),"m2":nomlp(rep(tt(K),1)),"m3":nomlp(rep(K,2))}.items():
    os.makedirs(name,exist_ok=True); open(name+'/train.py','w').write(s)
M2=nomlp(rep(tt(K),1))
for name,s in {"n128":M2.replace("GATE_BATCH = 4\nGATE_T = 256","GATE_BATCH = 8\nGATE_T = 128"),"n192":M2.replace("GATE_BATCH = 4\nGATE_T = 256","GATE_BATCH = 6\nGATE_T = 192"),"n4093":M2.replace("% 2039","% 4093").replace("(2039, nout)","(4093, nout)"),"nl05":M2.replace("GATE_TAB = 0.1","GATE_TAB = 0.05")}.items():
    os.makedirs(name,exist_ok=True); open(name+'/train.py','w').write(s)
def unh(s): return s
c1=nomlp(rep(tt(ag(g5(T),0.1,'("g4", "g5")')),1))
os.makedirs('c1',exist_ok=True); open('c1/train.py','w').write(c1)
def g6(s,r=4093):
    s=s.replace('"g5": od.zeros((2039, nout))}','"g5": od.zeros((2039, nout)), "g6": od.zeros((%d, nout))}'%r)
    s=s.replace('od.embedding(q["g5"], (x * 251 + od.concat([x[:, :1] * 0, x[:, :-1]], 1)) % 2039)','od.embedding(q["g5"], (x * 251 + od.concat([x[:, :1] * 0, x[:, :-1]], 1)) % 2039) + od.embedding(q["g6"], ((x * 251 + od.concat([x[:, :1] * 0, x[:, :-1]], 1)) * 251 + od.concat([x[:, :2] * 0, x[:, :-2]], 1)) % '+str(r)+')')
    return s.replace('GATE_TABLES = ("g4", "g5")','GATE_TABLES = ("g4", "g5", "g6")')
for name,s in {"x_lo":lo(M2),"x_t15":M2.replace("GATE_TAB = 0.1","GATE_TAB = 0.15"),"x_lr3":lr(M2,0.03),"x_g6":g6(M2)}.items():
    os.makedirs(name,exist_ok=True); open(name+'/train.py','w').write(s)
for name,s in {"y20":M2.replace("GATE_TAB = 0.1","GATE_TAB = 0.2"),"y30":M2.replace("GATE_TAB = 0.1","GATE_TAB = 0.3")}.items():
    os.makedirs(name,exist_ok=True); open(name+'/train.py','w').write(s)
C2=c1.replace("GATE_TAB = 0.1","GATE_TAB = 0.2")
for name,s in {"z06":share(C2,0.06),"z11":share(C2,0.11)}.items():
    os.makedirs(name,exist_ok=True); open(name+'/train.py','w').write(s)

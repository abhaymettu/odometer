#!/bin/bash
# usage: run.sh seed name [name...] ; one process per variant, dev split
cd /home/user/att/attempt-04
seed=$1; shift
for v in "$@"; do
  p=work/v/$v/train.py; [ -f "$p" ] || p=entries/$v/train.py
  ( python verify.py $p --split dev --seeds $seed, --jobs 1 --out work/r/$v-$seed.json 2>&1 | grep -E "seed |void" | sed "s/^/$v /" ) &
done
wait
date

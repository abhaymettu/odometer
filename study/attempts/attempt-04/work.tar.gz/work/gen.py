"""Build variants of the record entry by text substitution."""
import pathlib, re, sys
BASE = pathlib.Path('../entries/current/train.py').read_text()

def sub(s, a, b):
    assert a in s, a
    return s.replace(a, b)

def sampled(s, sample, full=0.15):
    """Low-order tables pay embedding backward only on some steps."""
    s = sub(s, 'COLD_EVERY = 16', f'COLD_EVERY = 16\nSAMPLE = {sample}\nFULL = {full}')
    s = sub(s, '''def mix(p, rows, masks=None):
    parts = [od.embedding(p[f"t{k}"], r) for k, r in enumerate(rows)]''',
    '''def mix(p, rows, masks=None, live=None):
    parts = [od.embedding(p[f"t{k}"] if live is None or live[k] else p[f"t{k}"].detach(), r) for k, r in enumerate(rows)]''')
    s = sub(s, '''od.cross_entropy(mix(p, order_rows(z), masks), fold(y[:, PAD:])).backward()''',
    '''live = [frac < FULL or step % e == 0 for e in SAMPLE]
        od.cross_entropy(mix(p, order_rows(z), masks, live), fold(y[:, PAD:])).backward()''')
    s = sub(s, '''                if step % tables[k]:
                    continue
                s[k] = s[k] + g * g''', '''                if g is None or step % tables[k]:
                    continue
                s[k] = s[k] + g * g''')
    return s

WORD = '''
def word_rows(z):
    """Causal word contexts. Rows for: current word prefix; plus previous word; plus the one before."""
    T = z.shape[1]
    ge65 = (z // 65 + 3) // 4
    low = z + (ge65 - (z // 97 + 1) // 2) * 32
    h = z[:, PAD:] * 0
    p1, p2 = h, h
    for n in range(WORD_K, 0, -1):
        a, b = PAD - n + 1, T - n + 1
        L = ge65[:, a:b]
        e = ge65[:, a - 1 : b - 1] * (1 - L)
        k = 1 - e
        p2 = p2 * k + p1 * e
        p1 = p1 * k + h * e
        h = (h * HASH_A + low[:, a:b]) * L
    c = z[:, PAD:]
    w0 = h * HASH_B + c
    w1 = w0 * HASH_A + p1
    w2 = w1 * HASH_A + p2
    return [(w * HASH_B + i) % r for w, i, r in zip((w0, w1, w2), (21, 22, 23), WROWS) if r]

'''

def word(s, orders, rows, every, wrows, maskn=(6, 10, 16), K=16):
    n = len(orders) + sum(1 for r in wrows if r)
    s = sub(s, 'ORDERS = (1, 2, 3, 4, 5, 6, 8, 10, 12)', f'ORDERS = {orders}\nWROWS = {wrows}\nWORD_K = {K}\nMASKN = {tuple(m for m, r in zip(maskn, wrows) if r)}')
    s = sub(s, 'ROWS = (256, 8191, 16381, 32749, 75989, 75989, 104003, 104003, 104003)', f'ROWS = {rows}')
    s = sub(s, 'EVERY = (1, 1, 1, 4, 8, 8, 16, 16, 16)', f'EVERY = {every}')
    s = sub(s, 'p = {f"t{k}": od.zeros((r, EMBED)) for k, r in enumerate(ROWS)}\n    n = EMBED * len(ROWS)',
            'p = {f"t{k}": od.zeros((r, EMBED)) for k, r in enumerate(ROWS + tuple(w for w in WROWS if w))}\n    n = EMBED * (len(ROWS) + len(MASKN))')
    s = sub(s, 'return [od.concat([od.zeros((1, n - 1, 1)), od.ones((1, T - n + 1, 1))], 1) for n in ORDERS]',
            'return [od.concat([od.zeros((1, n - 1, 1)), od.ones((1, T - n + 1, 1))], 1) for n in ORDERS + MASKN]')
    s = sub(s, '                out.append(h if n == 1 else (h * HASH_B + i) % ROWS[i])\n    return out\n',
            '                out.append(h if n == 1 else (h * HASH_B + i) % ROWS[i])\n    return out + word_rows(z)\n')
    s = sub(s, 'def history_masks(T):', WORD.lstrip('\n') + '\ndef history_masks(T):')
    return s


WH = '''
def word_hashes(z):
    """Causal word contexts. Hashes of: current word prefix; plus previous word; plus the one before."""
    T = z.shape[1]
    ge65 = (z // 65 + 3) // 4
    low = z + (ge65 - (z // 97 + 1) // 2) * 32
    h = z[:, PAD:] * 0
    p1, p2 = h, h
    for n in range(WORD_K, 0, -1):
        a, b = PAD - n + 1, T - n + 1
        L = ge65[:, a:b]
        e = ge65[:, a - 1 : b - 1] * (1 - L)
        k = 1 - e
        p2 = p2 * k + p1 * e
        p1 = p1 * k + h * e
        h = (h * HASH_A + low[:, a:b]) * L
    w0 = h * HASH_B + z[:, PAD:]
    w1 = w0 * HASH_A + p1
    return w0, w1, w1 * HASH_A + p2

'''

def localword(s, local):
    """In-window stages keyed on word hashes: order 101, 102, 103 in LOCAL mean w0, w1, w2."""
    s = re.sub(r'LOCAL = \(.*?\)\)  #', 'LOCAL = ' + repr(local) + '  #', s, count=1)
    if 'def word_rows' in s:
        s = sub(s, WORD.lstrip('\n'), WORD_SPLIT)
    else:
        s = sub(s, 'def raw_hashes(z):', WH.lstrip('\n') + 'def raw_hashes(z):')
        s = sub(s, 'PAD = 32', 'PAD = 32\nWORD_K = 16')
    s = sub(s, 'for n in range(1, max(i for i, b, d in LOCAL) + 1):', 'for n in range(1, max(i for i, b, d in LOCAL if i < 100) + 1):')
    s = sub(s, '        out[n] = h\n    return out\n', '        out[n] = h\n    w = word_hashes(z)\n    return out | {101: w[0], 102: w[1], 103: w[2]}\n')
    return s

WORD_SPLIT = WH.lstrip('\n') + '''def word_rows(z):
    return [(w * HASH_B + i) % r for w, i, r in zip(word_hashes(z), (21, 22, 23), WROWS) if r]

'''

def votes(s, tau=0, rho=None):
    """Weight in-window votes by recency (tau) and by whether the vote comes from the current story (rho)."""
    body = "    mask = od.tril(od.ones((1, T, T)), -1)\n"
    if tau:
        body += f"    idx = od.arange(T).reshape(1, T, 1)\n    mask = mask * od.exp((idx - idx.reshape(1, 1, T)) * {-1.0 / tau})\n"
    if rho is not None:
        body += ("    ends = od.sum(od.embedding(identity(256)[:, :1], x), -1, keepdims=True)\n"
                 "    run = od.tril(od.ones((1, T, T))) @ ends\n"
                 "    cross = (run - run.reshape(B, 1, T)) > 0.5\n"
                 f"    mask = mask * (1.0 - cross * {1.0 - rho})\n")
    return sub(s, "    mask = od.tril(od.ones((1, T, T)), -1)\n", body)

def const(s, **kw):
    for k, v in kw.items():
        s, n = re.subn(rf'^{k} = .*$', f'{k} = {v}', s, count=1, flags=re.M)
        assert n == 1, k
    return s


def freeze(s, at=0.9, peak=0.1):
    """Tables stop at frac = at, and the mixer alone trains on, three times the bytes per tick. Needs sampled()."""
    s = sub(s, 'live = [frac < FULL or step % e == 0 for e in SAMPLE]', f'live = [frac < {at} and (frac < FULL or step % e == 0) for e in SAMPLE]')
    s = sub(s, '        z, y = data.batch(BATCH, WINDOW + PAD)\n', f'        if frac > {at}:\n            sched = {peak} * 0.5 * (1 + math.cos(math.pi * (frac - {at}) / {1 - at}))\n        z, y = data.batch(BATCH, WINDOW + PAD)\n')
    return s

def bias1(s):
    """A per-last-byte logit bias in the final mix, fitted with the gate."""
    s = sub(s, 'q = {"g1":', 'q = {"g5": od.zeros((256, CLASSES)), "g1":')
    s = sub(s, 'return od.log(p0 + 1e-9) * a0 + od.log(p + 1e-9) * a1', 'return od.log(p0 + 1e-9) * a0 + od.log(p + 1e-9) * a1 + od.embedding(q["g5"], x)')
    s = sub(s, 'ROWS = (256, 8191, 16381, 32749, 75989, 75989, 104003, 104003, 104003)', 'ROWS = (256, 8191, 16381, 32749, 75989, 75989, 104003, 104003, 101503)')
    return s


def posfeat(s):
    """Gate features: how many earlier in-window positions vote, which is the distance into the current story."""
    s = sub(s, '        out.append((c, od.sum(c, -1, keepdims=True), od.sum(c > 0.0, -1, keepdims=True)))\n    return out\n',
               '        out.append((c, od.sum(c, -1, keepdims=True), od.sum(c > 0.0, -1, keepdims=True)))\n    return out + [od.sum(mask, -1, keepdims=True)]\n')
    s = sub(s, '    for c, t, k in stats:\n        seen = t > 0.0\n', '    parts += [od.log(stats[-1] + 1.0) * 0.25, stats[-1] < 16.0, stats[-1] < 64.0]\n    for c, t, k in stats[:-1]:\n        seen = t > 0.0\n')
    s = sub(s, 'nf = 3 + 5 * n', 'nf = 6 + 5 * n')
    return s


def zreset(s):
    """Table hashes stop at a story boundary, so a story's opening does not hash the end of the story before it."""
    s = sub(s, """    h = z[:, PAD:] * 0
    out = []
    for n in range(1, max(ORDERS) + 1):
        h = h * HASH_A + z[:, PAD - n + 1 : T - n + 1]
""", """    h = z[:, PAD:] * 0
    alive = h + 1
    nz = (z + 255) // 256
    out = []
    for n in range(1, max(ORDERS) + 1):
        h = h * HASH_A + z[:, PAD - n + 1 : T - n + 1] * alive
        alive = alive * nz[:, PAD - n + 1 : T - n + 1]
""")
    return s

V = {}
V['base'] = BASE
V['samp1'] = sampled(BASE, (4, 4, 4, 2, 1, 1, 1, 1, 1))
V['w10'] = word(BASE, (1,2,3,4,5,6,8,12), (256,8191,16381,32749,75989,75989,75989,75989), (1,1,1,4,8,8,16,16), (0,75989,75989))
V['w11'] = word(BASE, (1,2,3,4,5,6,8,12), (256,8191,16381,32749,65521,65521,65521,65521), (1,1,1,4,8,8,16,16,8,16,16), (32749,75989,65521))
L0 = ((1, 100.0, 0.02), (2, 22.7, 0.022), (3, 7.0, 0.343), (4, 5.5, 0.226), (6, 0.85, 0.684), (16, 0.39, 0.6))
V['lw1'] = localword(BASE, L0[:4] + ((102, 3.0, 0.4),) + L0[4:])
V['lw2'] = localword(BASE, L0[:3] + ((101, 6.0, 0.3),) + L0[3:4] + ((102, 3.0, 0.4),) + L0[4:])
V['dec'] = votes(BASE, tau=300)
V['story'] = votes(BASE, rho=0.25)
V['gate32'] = const(BASE, GATE=32)
V['gs12'] = const(BASE, GATE_SHARE=0.12)
V['samp2'] = sampled(BASE, (8, 8, 4, 2, 2, 1, 1, 1, 1))
V['samp3'] = sampled(BASE, (4, 4, 4, 2, 2, 2, 1, 1, 1))
V['samp4'] = sampled(BASE, (16, 16, 8, 4, 2, 1, 1, 1, 1), full=0.1)
V['wa'] = sampled(word(BASE, (1,2,3,4,5,6,8,10,12), (256,8191,16381,32749,75989,75989,93001,93001,93001), (1,1,1,4,8,8,16,16,16,8), (32749,0,0)), (4,4,4,2,1,1,1,1,1,1))
S1 = sampled(BASE, (4, 4, 4, 2, 1, 1, 1, 1, 1))
V['frz'] = freeze(S1)
V['frz2'] = freeze(S1, at=0.85, peak=0.2)
V['h96'] = const(S1, HIDDEN=96)
V['b1'] = bias1(S1)
LW2 = L0[:3] + ((101, 6.0, 0.3),) + L0[3:4] + ((102, 3.0, 0.4),) + L0[4:]
V['c1'] = votes(localword(S1, LW2), rho=0.25)
C1 = V['c1']
V['c1gt'] = const(C1, GATE_T=512, GATE_BATCH=2)
V['c1gs'] = const(C1, GATE_SHARE=0.12)
V['c1g32'] = const(C1, GATE=32)
V['c1r1'] = votes(localword(S1, LW2), rho=0.1)
V['c1r5'] = votes(localword(S1, LW2), rho=0.5)
V['c1w2'] = votes(localword(S1, LW2[:6] + ((103, 1.0, 0.5),) + LW2[6:]), rho=0.25)
def comb(rho=0.1, local=LW2, S=S1):
    return votes(localword(S, local), rho=rho)
V['c1r0'] = comb(0.0)
V['r1g32'] = const(comb(0.1), GATE=32)
V['r1frz'] = comb(0.1, S=freeze(S1))
V['r1h96'] = const(comb(0.1), HIDDEN=96)
V['r1pos'] = posfeat(comb(0.1))
V['r1w2'] = comb(0.1, LW2[:6] + ((103, 1.0, 0.5),) + LW2[6:])
V['r1gg'] = const(comb(0.1), GATE=32, GATE_SHARE=0.12)
V['r1s3'] = comb(0.1, S=V['samp3'])
V['r1o10'] = comb(0.1, LW2[:7] + ((10, 0.5, 0.65),) + LW2[7:])
L2 = LW2[:6] + ((103, 1.0, 0.5),) + LW2[6:7] + ((10, 0.5, 0.65),) + LW2[7:]
V['r2'] = const(comb(0.1, L2), GATE=32, GATE_SHARE=0.12)
V['r2h'] = const(comb(0.1, L2), GATE=32, GATE_SHARE=0.12, HIDDEN=96)
V['r1z'] = zreset(comb(0.1))
if __name__ == '__main__':
    for name in sys.argv[1:] or V:
        d = pathlib.Path('v')/name; d.mkdir(parents=True, exist_ok=True)
        (d/'train.py').write_text(V[name])
        print(name)

import sys;sys.path.insert(0,'.')
import numpy as np,os
from tune import *
Z=np.load(os.environ['TMPDIR']+'/p0H.npz');p0=Z['p0']
A=np.arange(1024)%2==0;B=~A
def sc(st):
    n=run(p0,st); return n[A].mean(),n[B].mean(),n.mean()
cur=[('o2',500.,.35),('o3',24.5,.6),('o4',8.4,.7),('o6',1.4,.6),('o16',.7,.5)]
print('start',sc(cur))
best=sc(cur)[0]
for it in range(2):
    for i in range(len(cur)):
        for bm in (.7,.85,1.2,1.4):
            st=list(cur); st[i]=(cur[i][0],cur[i][1]*bm,cur[i][2]); v=sc(st)[0]
            if v<best-1e-5: best,cur=v,st
        for dd in (-.2,-.1,.1,.2):
            d=cur[i][2]+dd
            if d<0 or d>=1: continue
            st=list(cur); st[i]=(cur[i][0],cur[i][1],d); v=sc(st)[0]
            if v<best-1e-5: best,cur=v,st
    print(it,[(a,round(b,2),round(c,2)) for a,b,c in cur],sc(cur),flush=True)

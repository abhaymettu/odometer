import re,sys
def var(name,base='v/cand.py',**kw):
    s=open(base).read()
    for k,v in kw.items():
        s,n=re.subn(rf'^{k} = .*$',f'{k} = {v}',s,flags=re.M); assert n==1,k
    open(f'v/{name}.py','w').write(s)

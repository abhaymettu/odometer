"""eval-only harness: load an entry's forward + saved params, report dev bpb and per-position nll. Uses engine in eval mode, no meter cap."""
import sys, json, pathlib, importlib.util, time
import numpy as np
ROOT='/home/user/att/attempt-01'; sys.path.insert(0,ROOT)
import odometer as od
from odometer import _data,_engine
def load(path):
    spec=importlib.util.spec_from_file_location('e'+str(abs(hash(path))),path); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
def run(entry, pdir, nwin=1024, split='dev'):
    m=load(entry); pdir=pathlib.Path(pdir)
    names=json.load(open(pdir/'names.json')); st=np.load(pdir/'params.npz'); arr={n:st[f'p{i}'] for i,n in enumerate(names)}
    W=_data.heldout_windows(split,512,1024)[:nwin]
    _engine._M.reset(None,0,mode='eval')
    out=[]
    for s in range(0,len(W),16):
        w=W[s:s+16]
        z=m.forward({k:od.Tensor(a) for k,a in arr.items()},od.Tensor(w[:,:512].astype(np.int32)))._d.astype(np.float64)
        lp=z-z.max(-1,keepdims=True); lp-=np.log(np.exp(lp).sum(-1,keepdims=True))
        out.append(-np.take_along_axis(lp,w[:,1:,None].astype(int),2)[:,:,0])
    nll=np.concatenate(out)/np.log(2)
    return nll,_engine._M.used/(len(W)*512)
if __name__=='__main__':
    t=time.time(); nll,tpb=run(sys.argv[1],sys.argv[2],int(sys.argv[3]) if len(sys.argv)>3 else 1024)
    print('bpb %.4f tpb %.0f sec %.0f'%(nll.mean(),tpb,time.time()-t))
    prof=nll.mean(0)
    print('first 24:',' '.join('%.2f'%v for v in prof[:24]))
    for a,b in [(0,8),(8,16),(16,32),(32,64),(64,128),(128,256),(256,512)]:
        print(a,b,'%.4f'%prof[a:b].mean())

#!/bin/bash
# par.sh seed name1 name2 ...
S=$1; shift
for n in "$@"; do ./run1.sh v/$n.py $S r/${n}_$S & done; wait

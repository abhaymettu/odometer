"""CAND"""

import math

import odometer as od

ORDERS = (1, 2, 3, 4, 5, 6, 8, 10, 12)
ROWS = (256, 8191, 16381, 32749, 75989, 75989, 99991, 99991, 99991)
EMBEDS = (8, 8, 8, 8, 8, 8, 8, 8, 8)
EVERY = (1, 1, 1, 4, 8, 8, 16, 16, 16)
WORD_KIND = ()
WORD_ROWS = ()
WORD_EMBEDS = ()
WORD_EVERY = ()
WORD_HIST = 12
HIDDEN = 64
BATCH = 128
WINDOW = 64
LR_TABLE = 0.25
LR_MIX = 8e-3
PAD = 32
LOCAL = ((2, 500.0, 0.35), (3, 24.5, 0.6), (4, 8.4, 0.7), (6, 1.4, 0.6), (16, 0.7, 0.5))  # in-window stages: (order, concentration, discount)
WARMUP = 0.02
HASH_A = 16777619
HASH_B = 2654435761 % (1 << 31)
CLASSES = 130
FLOOR = 1e-7
COLD_EVERY = 16
TABLE_S0 = 1e-7
DEEP = 0
ROUNDS = 4


def candidates():
    return (0, 10, *range(32, 96), *range(97, 123), 128, 147, 148, 152, 153, 156, 157, 226)


def init_params():
    rows, dims = ROWS + WORD_ROWS, EMBEDS + WORD_EMBEDS
    p = {f"t{k}": od.zeros((r, d)) for k, (r, d) in enumerate(zip(rows, dims))}
    n = sum(dims)
    p["up"] = od.randn((n, HIDDEN), 1.0 / math.sqrt(n))
    p["bias"] = od.ones((1, 1, HIDDEN))
    p["head"] = od.zeros((HIDDEN, CLASSES))
    if DEEP:
        p["deep"] = od.zeros((HIDDEN, HIDDEN))
    return {k: od.param(v) for k, v in p.items()}


def is_letter(b):
    return (b // 65 + 3) // 4


def word_hashes(z):
    """Hash of the current word's prefix and of the two words before it at each position, by doubling, so about
    forty engine calls for the whole batch instead of a scan per position. Words count up to 2**ROUNDS bytes."""
    L = is_letter(z)
    w, alive = (z + 1) * L, L
    mult = HASH_A
    for k in range(ROUNDS):
        s = 1 << k
        w = w[:, s:] + alive[:, s:] * w[:, :-s] * mult
        alive = alive[:, s:] * alive[:, :-s]
        L = L[:, s:]
        mult = mult * mult % (1 << 31)
    ended = (1 - L[:, 1:]) * L[:, :-1]
    prev1 = w[:, :-1] * ended
    has = ended
    w = w[:, 1:]
    for k in range(ROUNDS):
        s = 1 << k
        prev1 = prev1[:, s:] + (1 - has[:, s:]) * prev1[:, :-s]
        has = has[:, s:] + (1 - has[:, s:]) * has[:, :-s]
        w = w[:, s:]
    return w, prev1


def order_rows(z):
    """z holds PAD bytes of history, then the positions to predict. One tensor of table rows per context, (B, T)."""
    T = z.shape[1]
    h = z[:, PAD:] * 0
    out = []
    for n in range(1, max(ORDERS) + 1):
        h = h * HASH_A + z[:, PAD - n + 1 : T - n + 1]
        for i, order in enumerate(ORDERS):
            if order == n:
                out.append(h if n == 1 else (h * HASH_B + i) % ROWS[i])
    if WORD_ROWS:
        w, prev1 = word_hashes(z[:, :])
        P = T - PAD
        w, prev1 = w[:, -P:], prev1[:, -P:]
        c = {"w": w, "w1": w * 31 + prev1 * HASH_B}
        for i, kind in enumerate(WORD_KIND):
            out.append((c[kind] * HASH_B + i + 11) % WORD_ROWS[i])
    return out


def history_masks(T):
    """Per context, 0 at positions whose context reaches back before the start of the window, else 1. (1, T, 1)."""
    lens = list(ORDERS) + [WORD_HIST for r in WORD_ROWS]
    return [od.concat([od.zeros((1, n - 1, 1)), od.ones((1, T - n + 1, 1))], 1) for n in lens]


def mix(p, rows, masks=None):
    parts = [od.embedding(p[f"t{k}"], r) for k, r in enumerate(rows)]
    if masks:
        parts = [e * m for e, m in zip(parts, masks)]
    a = od.relu(od.concat(parts, -1) @ p["up"] + p["bias"])
    if DEEP:
        a = a + od.relu(a @ p["deep"])
    return (a * a) @ p["head"]


def raw_hashes(z):
    """Unreduced hash per in-window order, since a table's modulus would add false matches. (B, T)."""
    T = z.shape[1]
    h = z[:, PAD:] * 0
    out = {}
    for n in range(1, max(i for i, b, d in LOCAL) + 1):
        h = h * HASH_A + z[:, PAD - n + 1 : T - n + 1]
        out[n] = h
    return out


def window_votes(rows, x):
    B, T = x.shape
    d = rows.reshape(B, T, 1) - rows.reshape(B, 1, T)
    same = od.tril((d >= 0) * (d <= 0), -1)
    eye = od.tril(od.ones((256, 256))) - od.tril(od.ones((256, 256)), -1)
    follows = od.embedding(eye, x[:, 1:])
    return same[:, :, : T - 1] @ follows


def forward(params, x):
    z = od.concat([x[:, :PAD] * 0, x], 1)
    rows = order_rows(z)
    out = od.softmax(mix(params, rows, history_masks(x.shape[1])), -1)
    eye = od.tril(od.ones((256, 256))) - od.tril(od.ones((256, 256)), -1)
    place = od.zeros((CLASSES, 256))
    for b in candidates():
        place = od.concat([place[: b % CLASSES], place[b % CLASSES : b % CLASSES + 1] + eye[b : b + 1], place[b % CLASSES + 1 :]], 0)
    p = out @ place + FLOOR
    raw = raw_hashes(z)
    for n, beta, disc in LOCAL:
        c = window_votes(raw[n], x)
        total = od.sum(c, -1, keepdims=True)
        kinds = od.sum(c > 0.0, -1, keepdims=True)
        p = (od.relu(c - disc) + (kinds * disc + beta) * p) / (total + beta)
    return od.log(p + 1e-12)


def train(data):
    p = init_params()
    every = EVERY + WORD_EVERY
    tables = {f"t{k}": e for k, e in enumerate(every)}
    m = {k: od.zeros(v.shape) for k, v in p.items() if k not in tables}
    s = {k: od.full(v.shape, TABLE_S0 if k in tables else 1e-8) for k, v in p.items()}
    cold = history_masks(WINDOW)
    start, span = od.used(), od.remaining()
    worst, step = 0, 0
    while od.remaining() > 2 * worst + 1_000_000:
        before = od.used()
        frac = (before - start) / span
        sched = frac / WARMUP if frac < WARMUP else 0.5 * (1 + math.cos(math.pi * (frac - WARMUP) / (1 - WARMUP)))
        z, y = data.batch(BATCH, WINDOW + PAD)
        step += 1
        od.cross_entropy(mix(p, order_rows(z), cold if COLD_EVERY and step % COLD_EVERY == 0 else None), y[:, PAD:] % CLASSES).backward()
        c1, c2 = LR_MIX * sched / (1 - 0.9**step), 1 / (1 - 0.99**step)
        lrt = LR_TABLE * min(1.0, frac / WARMUP)
        for k, v in p.items():
            g = v.grad
            if k in tables:
                if step % tables[k]:
                    continue
                s[k] = s[k] + g * g
                v.update(v - g * od.rsqrt(s[k]) * lrt)
            else:
                m[k] = m[k] * 0.9 + g * 0.1
                s[k] = s[k] * 0.99 + g * g * 0.01
                v.update(v - m[k] * od.rsqrt(s[k] * c2 + 1e-16) * c1)
            v.grad = None
        worst = max(worst, od.used() - before)
    return p

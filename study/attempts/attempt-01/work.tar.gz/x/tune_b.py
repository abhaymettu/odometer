import sys;sys.path.insert(0,'.')
import numpy as np,os
from tune import *
p0=np.load(os.environ['TMPDIR']+'/p0_base11.npy')
A=np.arange(1024)%2==0;B=~A
def sc(st): 
    n=run(p0,st); return n[A].mean(),n[B].mean(),n.mean()
base=[('o3',35.,.6),('o4',6.,.6),('o6',2.,.6)]
print('base',sc(base))
cur=base
names=['o1','o2','o3','o4','o5','o6','o7','o8','o10','o12','o16','w','w1','w2','s13']
best=sc(cur)[0]
for it in range(3):
    # param perturb
    improved=False
    for i in range(len(cur)):
        for bm in (.5,.7,1.4,2.):
            st=list(cur); st[i]=(cur[i][0],cur[i][1]*bm,cur[i][2]); v=sc(st)[0]
            if v<best-1e-5: best,cur=v,st;improved=True
        for dd in (-.3,-.15,-.1,.1,.15,.25):
            d=cur[i][2]+dd
            if d<0 or d>=1: continue
            st=list(cur); st[i]=(cur[i][0],cur[i][1],d); v=sc(st)[0]
            if v<best-1e-5: best,cur=v,st;improved=True
    # add stage anywhere
    bestadd=None
    for nm in names:
        for b in (2,5,15,50,150,500):
            for pos in range(len(cur)+1):
                st=cur[:pos]+[(nm,float(b),.5)]+cur[pos:]
                v=sc(st)[0]
                if v<best-5e-5 and (bestadd is None or v<bestadd[0]): bestadd=(v,st)
    if bestadd: best,cur=bestadd;improved=True
    print(it,cur,sc(cur),flush=True)
    if not improved: break

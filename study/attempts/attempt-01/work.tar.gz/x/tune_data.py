"""compute target-only sufficient stats for in-window votes over many causal contexts on dev windows."""
import sys,pickle
import numpy as np
sys.path.insert(0,'/home/user/att/attempt-01')
from odometer import _data
W=_data.heldout_windows('dev',512,1024)
def ctxs(w):
    # yields per position dict name->key
    out={}
    word=[];prev='';prev2=''
    res=[]
    b=bytes(w.tolist())
    for t in range(512):
        c=b[t]
        if c>=65: word.append(c)
        else:
            if word: prev2=prev; prev=bytes(word)
            word=[]
        d={}
        for n in (1,2,3,4,5,6,7,8,10,12,16,20,24,32):
            d[f'o{n}']=b[max(0,t-n+1):t+1] if t>=n-1 else None
        d['w']=bytes(word)
        d['w1']=(bytes(word),prev)
        d['w2']=(bytes(word),prev,prev2)
        d['s13']=(b[t-2:t-1],b[t:t+1]) if t>=2 else None  # skip
        res.append(d)
    return res
names=None
S={}
for i,w in enumerate(W):
    R=ctxs(w)
    if names is None:
        names=list(R[0]); S={n:np.zeros((1024,512,3),np.float32) for n in names}
    tab={n:{} for n in names}
    for t in range(512):
        y=int(w[t+1])
        for n in names:
            k=R[t][n]
            if k is None: continue
            e=tab[n].get(k)
            if e is None: e=tab[n][k]={}
            S[n][i,t]=(e.get(y,0),sum(e.values()),len(e))
            e[y]=e.get(y,0)+1
np.savez('/tmp/claude-1000/tunestats.npz' if False else sys.argv[1],**S)
print(names)

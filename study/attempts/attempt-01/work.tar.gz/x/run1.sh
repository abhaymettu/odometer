#!/bin/bash
# usage: run1.sh entry.py seed outdir [split]  -- train+eval keeping params
E=$(realpath $1); S=$2; O=$3; mkdir -p $O; O=$(realpath $O)
ROOT=/home/user/att/attempt-01
python3 -c "import sys,json;sys.path.insert(0,'$ROOT');import verify;json.dump(verify.TRACK,open('$O/track.json','w'))"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
cd $O
python3 -I $ROOT/verify.py --child-train $E $S $O > $O/train.log 2>&1
python3 -I $ROOT/verify.py --child-eval $E $S dev $O > $O/eval.log 2>&1
python3 -c "
import json;t=json.load(open('$O/train.json'));e=json.load(open('$O/eval.json'))
print('$E'.split('/')[-1],'$S',t['status'],e['status'],e['bpb'],'ticks %.3g'%t['train_ticks'],'trainsec %.0f'%t['train_seconds'],'evtpb %.0f'%e['eval_ticks_per_byte'],'evsec %.0f'%e['eval_seconds'],'params',t['params'],'lines',t['train_python_lines'],e['eval_python_lines'])
" | tee -a /home/user/att/attempt-01/x/results.txt

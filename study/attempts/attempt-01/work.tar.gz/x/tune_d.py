import sys,os;sys.path.insert(0,'.');sys.path.insert(0,'..')
import numpy as np
from odometer import _data
from tune import S
Z=np.load(os.environ['TMPDIR']+'/p0H.npz');p0=Z['p0'];H=Z['H']
W=_data.heldout_windows('dev',512,1024)
ORD=[2,3,4,6]
LAM={64:.5**(1/64),128:.5**(1/128),256:.5**(1/256),512:.5**(1/512)}
DISC={2:.35,3:.6,4:.7,6:.6}
D={}
for n in ORD:
  for hl,lam in LAM.items():
    arr=np.zeros((1024,512,3),np.float32);dd=DISC[n]
    pw=lam**np.arange(513)
    for i,w in enumerate(W):
        b=w.tobytes(); tab={}
        for t in range(n-1,512):
            k=b[t-n+1:t+1]; y=b[t+1]
            e=tab.get(k)
            if e is None:
                tab[k]=[(t,y)]; continue
            cc={}
            for s,v in e:
                cc[v]=cc.get(v,0.)+pw[t-s]
            arr[i,t]=(cc.get(y,0.),sum(cc.values()),sum(min(x,dd) for x in cc.values()))
            e.append((t,y))
    D[(n,hl)]=arr
    print(n,hl,flush=True)
np.save(os.environ['TMPDIR']+'/decay.npy',D,allow_pickle=True)
LOCAL=[(2,500.,.35),(3,24.5,.6),(4,8.4,.7),(6,1.4,.6),('16',.7,.5)]
def run(cfg):
    p=p0.copy()
    for (n,beta,d),hl in zip(LOCAL,cfg):
        name='o'+str(n)
        c,tot,k=[S[name][...,j] for j in range(3)]
        m=k*d
        if hl: c,tot,m=D[(n,hl)][...,0],D[(n,hl)][...,1],D[(n,hl)][...,2]
        p=(np.maximum(c-d,0)+(m+beta)*p)/(tot+beta)
    return -np.log2(p+1e-12).mean()
print('base',run([0,0,0,0,0]))
for i in range(4):
    for hl in LAM:
        cfg=[0]*5;cfg[i]=hl
        print(ORD[i],hl,'%.4f'%run(cfg),flush=True)
for hl in LAM:
    print('all',hl,'%.4f'%run([hl,hl,hl,hl,0]))

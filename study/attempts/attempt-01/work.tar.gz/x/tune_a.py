import sys;sys.path.insert(0,'.')
import numpy as np,os,evalx
from tune import *
nll,_=evalx.run('v/mask_nolocal.py','r/base_11')
p0=2.0**(-nll)
np.save(os.environ['TMPDIR']+'/p0_base11.npy',p0)
A=np.arange(1024)%2==0
base=[('o3',35,.6),('o4',6,.6),('o6',2,.6)]
print('base',score(p0,base))
for name in S:
    for beta in (1,3,10,30):
      for pos in ('end','start'):
        st=base+[(name,beta,.6)] if pos=='end' else [(name,beta,.6)]+base
        print(name,beta,pos,'%.4f'%score(p0,st))

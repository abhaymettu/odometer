import numpy as np,sys,os,itertools
S=np.load(os.environ['TMPDIR']+'/tunestats.npz'); S={k:S[k] for k in S.files}
def run(p0,stages,idx=None):
    p=p0.copy()
    for name,beta,d in stages:
        c,tot,k=[S[name][...,i] for i in range(3)]
        p=(np.maximum(c-d,0)+(k*d+beta)*p)/(tot+beta)
    p=p+1e-12
    return -np.log2(p)
def score(p0,st,sel=None):
    n=run(p0,st)
    return n.mean() if sel is None else n[sel].mean()

import sys;sys.path.insert(0,'.')
import numpy as np,os,re,evalx
sys.path.insert(0,'..')
import odometer as od
from odometer import _data,_engine
from tune import S
src=open('v/f_cls.py').read()
src=re.sub(r'^LOCAL = .*$','LOCAL = ((1, 1.0, 0.5),)',src,flags=re.M).replace('for n, beta, disc in LOCAL:','for n, beta, disc in ():')
open('v/tmp_nl.py','w').write(src)
m=evalx.load('v/tmp_nl.py')
import json,pathlib
pdir=pathlib.Path('r/f_cls_11')
names=json.load(open(pdir/'names.json')); st=np.load(pdir/'params.npz'); arr={n:st[f'p{i}'] for i,n in enumerate(names)}
W=_data.heldout_windows('dev',512,1024)
_engine._M.reset(None,0,mode='eval')
P=[];H=[];MX=[]
for s in range(0,1024,16):
    w=W[s:s+16]
    z=m.forward({k:od.Tensor(a) for k,a in arr.items()},od.Tensor(w[:,:512].astype(np.int32)))._d.astype(np.float64)
    lp=z-z.max(-1,keepdims=True); lp-=np.log(np.exp(lp).sum(-1,keepdims=True))
    P.append(np.exp(np.take_along_axis(lp,w[:,1:,None].astype(int),2)[:,:,0]))
    pp=np.exp(lp); H.append(-(pp*lp).sum(-1)); MX.append(pp.max(-1))
p0=np.concatenate(P);H=np.concatenate(H);MX=np.concatenate(MX)
np.savez(os.environ['TMPDIR']+'/p0H.npz',p0=p0,H=H,MX=MX)
print('nolocal',-np.log2(p0).mean(),'H',H.mean())
LOCAL=[('o2',500.,.35),('o3',24.5,.6),('o4',8.4,.7),('o6',1.4,.6),('o16',.7,.5)]
def run(gam,scale=None,local=LOCAL,feat=H):
    p=p0.copy()
    for i,(name,beta,d) in enumerate(local):
        c,tot,k=[S[name][...,j] for j in range(3)]
        g=gam[i] if isinstance(gam,(list,tuple)) else gam
        b=beta*np.exp(g*(feat-feat.mean()))
        p=(np.maximum(c-d,0)+(k*d+b)*p)/(tot+b)
    return -np.log2(p+1e-12)


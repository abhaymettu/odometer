import sys;sys.path.insert(0,'.')
import numpy as np,evalx
a,_=evalx.run('../entries/current/train.py','r/base_11')
b,tpb=evalx.run('v/clean.py','r/k_rows_11')
wa,wb=a.mean(1),b.mean(1)
d=wa-wb
n=len(d)
print('record %.4f new %.4f gain %.4f tpb %.0f'%(wa.mean(),wb.mean(),d.mean(),tpb))
print('window SE of level: new %.4f; paired SE of gain %.5f'%(wb.std(ddof=1)/n**.5,d.std(ddof=1)/n**.5))
print('gain on odd/even windows %.4f %.4f'%(d[::2].mean(),d[1::2].mean()))
print('level odd/even %.4f %.4f'%(wb[::2].mean(),wb[1::2].mean()))
pa,pb=a.mean(0),b.mean(0)
print('gain pos<16 contribution %.4f, pos>=16 %.4f'%((pa-pb)[:16].sum()/512,(pa-pb)[16:].sum()/512))

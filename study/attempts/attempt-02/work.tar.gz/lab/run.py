"""Exploration runner: train+eval one seed with verify's own children, keeping the params. usage: run.py entry seed outdir [budget]"""
import json, os, pathlib, subprocess, sys
ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
import verify
entry, seed, out = pathlib.Path(sys.argv[1]).resolve(), int(sys.argv[2]), pathlib.Path(sys.argv[3]).resolve()
budget = float(sys.argv[4]) if len(sys.argv) > 4 else None
out.mkdir(parents=True, exist_ok=True)
track = dict(verify.TRACK)
if budget: track["train_budget"] = int(budget)
(out / "track.json").write_text(json.dumps(track))
env = {"PATH": os.environ.get("PATH", ""), **{v: "1" for v in verify.THREAD_VARS}}
res = {}
for stage, extra in (("train", []), ("eval", ["dev"])):
    log = open(out / f"{stage}.log", "wb")
    subprocess.run([sys.executable, "-I", str(ROOT / "verify.py"), f"--child-{stage}", str(entry), str(seed), *extra, str(out)], cwd=out, env=env, stdout=log, stderr=subprocess.STDOUT)
    p = out / f"{stage}.json"
    if not p.exists():
        print("CRASH", stage, (out / f"{stage}.log").read_text()[-1500:]); sys.exit(1)
    res |= json.loads(p.read_text())
    if res["status"] != "ok": break
print(entry.parent.name, seed, res.get("status"), "bpb", res.get("bpb"), "ticks %.3e" % res.get("train_ticks", 0), "train_s %.0f" % res.get("train_seconds", 0), "eval_tpb", res.get("eval_ticks_per_byte"), "eval_s", res.get("eval_seconds"), "lines", res.get("train_python_lines"), "rss", res.get("peak_rss_mb"))

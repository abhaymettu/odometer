"""proto.py entry params_dir gate_budget [nwin]: fit only the gate on saved tables, then score on a dev subset."""
import importlib.util, json, sys, time, pathlib
import numpy as np
ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
import odometer as od
from odometer import _data, _engine
entry, pdir, gb = sys.argv[1], pathlib.Path(sys.argv[2]), float(sys.argv[3])
nwin = int(sys.argv[4]) if len(sys.argv) > 4 else 256
spec = importlib.util.spec_from_file_location("entry", entry); M = importlib.util.module_from_spec(spec); spec.loader.exec_module(M)
names = json.loads((pdir / "names.json").read_text()); st = np.load(pdir / "params.npz")
base = {n: st[f"p{i}"] for i, n in enumerate(names) if not n.startswith("g")}
_engine._M.reset(int(gb), 7)
data = _data.TrainData()
p = {k: od.param(od.Tensor(v.copy())) for k, v in base.items()}
t0 = time.time()
q = M.fit_gate(p, data)
print("fit s", time.time() - t0, "ticks", _engine._M.used)
all_p = {k: od.Tensor(v._d) for k, v in {**p, **q}.items()}
w = _data.heldout_windows("dev", 512, 1024)
w = w[np.random.default_rng(5).permutation(len(w))[:nwin]]
_engine._M.reset(None, 8, mode="eval")
tot = 0.0; t0 = time.time()
for s in range(0, len(w), 16):
    b = w[s:s+16]
    u0 = _engine._M.used
    z = M.forward(all_p, od.Tensor(b[:, :512].astype(np.int32)))._d.astype(np.float64)
    tpb = (_engine._M.used - u0) / b[:, :512].size
    lp = z - z.max(-1, keepdims=True); lp -= np.log(np.exp(lp).sum(-1, keepdims=True))
    tot += -np.take_along_axis(lp, b[:, 1:, None].astype(int), 2).sum()
print("bpb subset", tot / (len(w) * 512) / np.log(2), "eval tpb", tpb, "eval s", time.time() - t0)
for k in q:
    a = q[k]._d; print(k, a.shape, "abs mean %.3f max %.3f" % (np.abs(a).mean(), np.abs(a).max()))
np.savez(sys.argv[1] + ".gate.npz", **{k: v._d for k, v in q.items()})
if hasattr(M, "gates"):
    _engine._M.reset(None, 9)
    with od.no_grad():
        w = data.batch(8, 512 + 32)[0]
        x = w[:, 32:]
        P = {k: v for k, v in all_p.items()}
        p0 = M.base_probs(P, w, x); st = M.local_stats(w, x)
        o = M.gates(P, M.features(p0, st), x)._d
    print("mean gate out", np.round(o.mean((0, 1)), 3).tolist())
    print("sd gate out", np.round(o.std((0, 1)), 3).tolist())

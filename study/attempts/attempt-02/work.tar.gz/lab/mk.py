"""mk.py base new 'OLD=>NEW' ... : derive a variant by exact string replacement (each must match)."""
import sys, pathlib
base, new = sys.argv[1], sys.argv[2]
s = open(f'lab/{base}/train.py').read()
for r in sys.argv[3:]:
    a, b = r.split('=>')
    assert a in s, a
    s = s.replace(a, b)
pathlib.Path(f'lab/{new}').mkdir(exist_ok=True)
open(f'lab/{new}/train.py','w').write(s)
